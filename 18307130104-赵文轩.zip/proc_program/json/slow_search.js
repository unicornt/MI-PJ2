{
  "type": "Program",
  "body": [
    {
      "type": "ExpressionStatement",
      "expression": {
        "type": "CallExpression",
        "callee": {
          "type": "Identifier",
          "name": "load"
        },
        "arguments": [
          {
            "type": "Literal",
            "value": "base.js",
            "raw": "\"base.js\""
          }
        ]
      }
    },
    {
      "type": "ExpressionStatement",
      "expression": {
        "type": "CallExpression",
        "callee": {
          "type": "Identifier",
          "name": "load"
        },
        "arguments": [
          {
            "type": "Literal",
            "value": "base_search.js",
            "raw": "\"base_search.js\""
          }
        ]
      }
    },
    {
      "type": "ExpressionStatement",
      "expression": {
        "type": "CallExpression",
        "callee": {
          "type": "Identifier",
          "name": "createSlowBenchmarkSuite"
        },
        "arguments": [
          {
            "type": "Literal",
            "value": "Search",
            "raw": "\"Search\""
          }
        ]
      }
    }
  ],
  "sourceType": "script"
}