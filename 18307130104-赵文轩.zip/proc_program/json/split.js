{
  "type": "Program",
  "body": [
    {
      "type": "ExpressionStatement",
      "expression": {
        "type": "CallExpression",
        "callee": {
          "type": "Identifier",
          "name": "load"
        },
        "arguments": [
          {
            "type": "Literal",
            "value": "base.js",
            "raw": "\"base.js\""
          }
        ]
      }
    },
    {
      "type": "ExpressionStatement",
      "expression": {
        "type": "CallExpression",
        "callee": {
          "type": "Identifier",
          "name": "load"
        },
        "arguments": [
          {
            "type": "Literal",
            "value": "base_split.js",
            "raw": "\"base_split.js\""
          }
        ]
      }
    },
    {
      "type": "ExpressionStatement",
      "expression": {
        "type": "CallExpression",
        "callee": {
          "type": "Identifier",
          "name": "createBenchmarkSuite"
        },
        "arguments": [
          {
            "type": "Literal",
            "value": "Split",
            "raw": "\"Split\""
          }
        ]
      }
    }
  ],
  "sourceType": "script"
}