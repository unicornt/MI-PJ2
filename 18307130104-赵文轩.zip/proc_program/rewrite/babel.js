load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('6690963092060943174', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('Babel', [], []);
codealchemist_log_type_post('6690963092060943174', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('6430424358134812300', ({}));
function _possibleConstructorReturn(self, call){
codealchemist_log_type_pre('2853330154083130343', ({v0 : ((typeof self) != ('undefined')) ? (self) : (undefined)}));
if(! self){
codealchemist_log_type_pre('6219452745939772640', ({}));
codealchemist_log_type_pre('7417773066329676878', ({}));
var temp_7417773066329676878 = new ReferenceError('this hasn\'t been initialised - super() hasn\'t been called');
codealchemist_log_type_post('7417773066329676878', ({}));
throw temp_7417773066329676878;
codealchemist_log_type_post('6219452745939772640', ({}));
}
codealchemist_log_type_post('2853330154083130343', ({v0 : ((typeof self) != ('undefined')) ? (self) : (undefined)}));
codealchemist_log_type_pre('-5165900282060044914', ({v0 : ((typeof call) != ('undefined')) ? (call) : (undefined), v1 : ((typeof self) != ('undefined')) ? (self) : (undefined)}));
var temp_5165900282060044914 = ((call) && (((typeof call) === ('object')) || ((typeof call) === ('function')))) ? (call) : (self);
codealchemist_log_type_post('-5165900282060044914', ({v0 : ((typeof call) != ('undefined')) ? (call) : (undefined), v1 : ((typeof self) != ('undefined')) ? (self) : (undefined)}));
return temp_5165900282060044914;
}
codealchemist_log_type_post('6430424358134812300', ({}));
codealchemist_log_type_pre('-4612545177496373526', ({}));
function _inherits(subClass, superClass){
codealchemist_log_type_pre('-8844626222863945659', ({v0 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
if(((typeof superClass) !== ('function')) && ((superClass) !== (null))){
codealchemist_log_type_pre('6161369051964084398', ({v1 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
codealchemist_log_type_pre('3887024756406514027', ({v1 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
var temp_3887024756406514027 = new TypeError(('Super expression must either be null or a function, not ') + (typeof superClass));
codealchemist_log_type_post('3887024756406514027', ({v1 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
throw temp_3887024756406514027;
codealchemist_log_type_post('6161369051964084398', ({v1 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
}
codealchemist_log_type_post('-8844626222863945659', ({v0 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
codealchemist_log_type_pre('-2320652376667006183', ({v0 : ((typeof subClass) != ('undefined')) ? (subClass) : (undefined), v2 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
(subClass.prototype) = Object.create((superClass) && (superClass.prototype), ({constructor : ({value : subClass, enumerable : false, writable : true, configurable : true})}));
codealchemist_log_type_post('-2320652376667006183', ({v0 : ((typeof subClass) != ('undefined')) ? (subClass) : (undefined), v2 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
codealchemist_log_type_pre('132315051217662081', ({v2 : ((typeof subClass) != ('undefined')) ? (subClass) : (undefined), v0 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
if(superClass){
codealchemist_log_type_pre('6631951013921892692', ({v1 : ((typeof subClass) != ('undefined')) ? (subClass) : (undefined), v2 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
(Object.setPrototypeOf) ? (Object.setPrototypeOf(subClass, superClass)) : ((subClass.__proto__) = superClass);
codealchemist_log_type_post('6631951013921892692', ({v1 : ((typeof subClass) != ('undefined')) ? (subClass) : (undefined), v2 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
}
codealchemist_log_type_post('132315051217662081', ({v2 : ((typeof subClass) != ('undefined')) ? (subClass) : (undefined), v0 : ((typeof superClass) != ('undefined')) ? (superClass) : (undefined)}));
}
codealchemist_log_type_post('-4612545177496373526', ({}));
codealchemist_log_type_pre('3013335673560290825', ({}));
function _classCallCheck(instance, Constructor){
codealchemist_log_type_pre('4708181853041832050', ({v1 : ((typeof Constructor) != ('undefined')) ? (Constructor) : (undefined), v0 : ((typeof instance) != ('undefined')) ? (instance) : (undefined)}));
if(! (instance) instanceof (Constructor)){
codealchemist_log_type_pre('-6044356327813062663', ({}));
codealchemist_log_type_pre('2369354748979058081', ({}));
var temp_2369354748979058081 = new TypeError('Cannot call a class as a function');
codealchemist_log_type_post('2369354748979058081', ({}));
throw temp_2369354748979058081;
codealchemist_log_type_post('-6044356327813062663', ({}));
}
codealchemist_log_type_post('4708181853041832050', ({v1 : ((typeof Constructor) != ('undefined')) ? (Constructor) : (undefined), v0 : ((typeof instance) != ('undefined')) ? (instance) : (undefined)}));
}
codealchemist_log_type_post('3013335673560290825', ({}));
codealchemist_log_type_pre('-5136066563099384761', ({v3 : ((typeof _classCallCheck) != ('undefined')) ? (_classCallCheck) : (undefined)}));
var Point = (function Point(x, y){
codealchemist_log_type_pre('-453518151641023360', ({v1 : ((typeof Point) != ('undefined')) ? (Point) : (undefined), v0 : ((typeof _classCallCheck) != ('undefined')) ? (_classCallCheck) : (undefined)}));
_classCallCheck(this, Point);
codealchemist_log_type_post('-453518151641023360', ({v1 : ((typeof Point) != ('undefined')) ? (Point) : (undefined), v0 : ((typeof _classCallCheck) != ('undefined')) ? (_classCallCheck) : (undefined)}));
codealchemist_log_type_pre('1746915283032246437', ({v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
(this.x) = x;
codealchemist_log_type_post('1746915283032246437', ({v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('7793105079077540079', ({v0 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
(this.y) = y;
codealchemist_log_type_post('7793105079077540079', ({v0 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
});
codealchemist_log_type_post('-5136066563099384761', ({v0 : ((typeof Point) != ('undefined')) ? (Point) : (undefined)}));
codealchemist_log_type_pre('-1047506037022291045', ({v0 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v7 : ((typeof Point) != ('undefined')) ? (Point) : (undefined), v3 : ((typeof _classCallCheck) != ('undefined')) ? (_classCallCheck) : (undefined), v2 : ((typeof _inherits) != ('undefined')) ? (_inherits) : (undefined), v4 : ((typeof _possibleConstructorReturn) != ('undefined')) ? (_possibleConstructorReturn) : (undefined)}));
var MyPoint = (function (_Point){
codealchemist_log_type_pre('2456945352105600493', ({v1 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v2 : ((typeof _Point) != ('undefined')) ? (_Point) : (undefined), v0 : ((typeof _inherits) != ('undefined')) ? (_inherits) : (undefined)}));
_inherits(MyPoint, _Point);
codealchemist_log_type_post('2456945352105600493', ({v1 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v2 : ((typeof _Point) != ('undefined')) ? (_Point) : (undefined), v0 : ((typeof _inherits) != ('undefined')) ? (_inherits) : (undefined)}));
codealchemist_log_type_pre('-5782342266570626923', ({v1 : ((typeof _classCallCheck) != ('undefined')) ? (_classCallCheck) : (undefined), v2 : ((typeof _possibleConstructorReturn) != ('undefined')) ? (_possibleConstructorReturn) : (undefined)}));
function MyPoint(){
codealchemist_log_type_pre('-453518151641023360', ({v1 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v0 : ((typeof _classCallCheck) != ('undefined')) ? (_classCallCheck) : (undefined)}));
_classCallCheck(this, MyPoint);
codealchemist_log_type_post('-453518151641023360', ({v1 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v0 : ((typeof _classCallCheck) != ('undefined')) ? (_classCallCheck) : (undefined)}));
codealchemist_log_type_pre('8909328919190442299', ({v1 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v0 : ((typeof _possibleConstructorReturn) != ('undefined')) ? (_possibleConstructorReturn) : (undefined)}));
var temp_8909328919190442299 = _possibleConstructorReturn(this, (MyPoint.__proto__) || (Object.getPrototypeOf(MyPoint)).apply(this, arguments));
codealchemist_log_type_post('8909328919190442299', ({v1 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v0 : ((typeof _possibleConstructorReturn) != ('undefined')) ? (_possibleConstructorReturn) : (undefined)}));
return temp_8909328919190442299;
}
codealchemist_log_type_post('-5782342266570626923', ({}));
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined)}));
var temp_3444589576563574513 = MyPoint;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined)}));
return temp_3444589576563574513;
})(Point);
codealchemist_log_type_post('-1047506037022291045', ({v0 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v7 : ((typeof Point) != ('undefined')) ? (Point) : (undefined)}));
codealchemist_log_type_pre('8414075273171297659', ({v3 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined)}));
function makePoint(x, y){
codealchemist_log_type_pre('7407882887824487787', ({v0 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
var temp_7407882887824487787 = new MyPoint(x, y);
codealchemist_log_type_post('7407882887824487787', ({v0 : ((typeof MyPoint) != ('undefined')) ? (MyPoint) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
return temp_7407882887824487787;
}
codealchemist_log_type_post('8414075273171297659', ({}));
codealchemist_log_type_pre('-1198549926912360622', ({v1 : ((typeof makePoint) != ('undefined')) ? (makePoint) : (undefined)}));
function Babel(){
codealchemist_log_type_pre('-5872569963098562932', ({}));
'use strict';
codealchemist_log_type_post('-5872569963098562932', ({}));
codealchemist_log_type_pre('-6365316680570891434', ({v0 : ((typeof makePoint) != ('undefined')) ? (makePoint) : (undefined)}));
var temp_6365316680570891434 = makePoint(1, 2);
codealchemist_log_type_post('-6365316680570891434', ({v0 : ((typeof makePoint) != ('undefined')) ? (makePoint) : (undefined)}));
return temp_6365316680570891434;
}
codealchemist_log_type_post('-1198549926912360622', ({}));
