load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('-7265530382583183660', ({}));
var re;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-8087017393409383734', ({v2 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
function Global(){
codealchemist_log_type_pre('-3123283519248670612', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
var g = re.global;
codealchemist_log_type_post('-3123283519248670612', ({v0 : ((typeof g) != ('undefined')) ? (g) : (undefined), v1 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
}
codealchemist_log_type_post('-8087017393409383734', ({}));
codealchemist_log_type_pre('4150547624862969379', ({v2 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
function Flags(){
codealchemist_log_type_pre('-6682701525838411296', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
var f = re.flags;
codealchemist_log_type_post('-6682701525838411296', ({v0 : ((typeof f) != ('undefined')) ? (f) : (undefined), v1 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
}
codealchemist_log_type_post('4150547624862969379', ({}));
codealchemist_log_type_pre('-692396474941819402', ({}));
function Setup(){
codealchemist_log_type_pre('5096000353331030114', ({}));
(re) = /[Cz]/giym;
codealchemist_log_type_post('5096000353331030114', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
}
codealchemist_log_type_post('-692396474941819402', ({}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var benchmarks = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof benchmarks) != ('undefined')) ? (benchmarks) : (undefined)}));
