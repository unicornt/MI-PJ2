load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
codealchemist_log_type_pre('-7265530382583183660', ({}));
var str;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
codealchemist_log_type_pre('-7265530382583183660', ({}));
var re;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('6052530710383821160', ({v2 : ((typeof re) != ('undefined')) ? (re) : (undefined), v1 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
function StringReplace1(){
codealchemist_log_type_pre('-7848084120903196789', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
str.replace(re, "");
codealchemist_log_type_post('-7848084120903196789', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('6052530710383821160', ({}));
codealchemist_log_type_pre('2851103739561717274', ({v2 : ((typeof re) != ('undefined')) ? (re) : (undefined), v1 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
function StringReplace2(){
codealchemist_log_type_pre('2774035941228281125', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
str.replace(re, "xyz");
codealchemist_log_type_post('2774035941228281125', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('2851103739561717274', ({}));
codealchemist_log_type_pre('-879378377632917606', ({v2 : ((typeof re) != ('undefined')) ? (re) : (undefined), v1 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
function StringReplace3(){
codealchemist_log_type_pre('-4113654128742457982', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
str.replace(re, "x$1yz");
codealchemist_log_type_post('-4113654128742457982', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-879378377632917606', ({}));
codealchemist_log_type_pre('-365501977086161492', ({v2 : ((typeof re) != ('undefined')) ? (re) : (undefined), v1 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
function FunctionReplace1(){
codealchemist_log_type_pre('-8510001852917991167', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
str.replace(re, String);
codealchemist_log_type_post('-8510001852917991167', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-365501977086161492', ({}));
codealchemist_log_type_pre('-6354574074603030189', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Replace1Setup(){
codealchemist_log_type_pre('-8084886703000221054', ({}));
(re) = /[Cz]/;
codealchemist_log_type_post('-8084886703000221054', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-6354574074603030189', ({}));
codealchemist_log_type_pre('39612794529508049', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Replace2Setup(){
codealchemist_log_type_pre('-2809384762700861935', ({}));
(re) = /[Cz]/g;
codealchemist_log_type_post('-2809384762700861935', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('39612794529508049', ({}));
codealchemist_log_type_pre('1647562948443808369', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Replace3Setup(){
codealchemist_log_type_pre('776533537118453776', ({}));
(re) = /([Cz])/;
codealchemist_log_type_post('776533537118453776', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('1647562948443808369', ({}));
codealchemist_log_type_pre('2553058411424655561', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Replace4Setup(){
codealchemist_log_type_pre('-7952769501584124854', ({}));
(re) = /([Cz])/g;
codealchemist_log_type_post('-7952769501584124854', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('2553058411424655561', ({}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var benchmarks = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof benchmarks) != ('undefined')) ? (benchmarks) : (undefined)}));
