load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
codealchemist_log_type_pre('-7265530382583183660', ({}));
var str;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
codealchemist_log_type_pre('-7265530382583183660', ({}));
var re;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-8946487882811281708', ({v2 : ((typeof re) != ('undefined')) ? (re) : (undefined), v1 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
function SimpleSplit(){
codealchemist_log_type_pre('3582354472058128355', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
str.split(re);
codealchemist_log_type_post('3582354472058128355', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-8946487882811281708', ({}));
codealchemist_log_type_pre('-6354574074603030189', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Split1Setup(){
codealchemist_log_type_pre('-8084886703000221054', ({}));
(re) = /[Cz]/;
codealchemist_log_type_post('-8084886703000221054', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-6354574074603030189', ({}));
codealchemist_log_type_pre('1044874067698704293', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Split2Setup(){
codealchemist_log_type_pre('-8285496237296235783', ({}));
(re) = /[Cz]/u;
codealchemist_log_type_post('-8285496237296235783', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('1044874067698704293', ({}));
codealchemist_log_type_pre('-2408623307849893495', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Split3Setup(){
codealchemist_log_type_pre('4179019215767655208', ({}));
(re) = /[Cz]/y;
codealchemist_log_type_post('4179019215767655208', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-2408623307849893495', ({}));
codealchemist_log_type_pre('-6554935898924133934', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Split4Setup(){
codealchemist_log_type_pre('-3284038167726591588', ({}));
(re) = /[Cz]/uy;
codealchemist_log_type_post('-3284038167726591588', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-6554935898924133934', ({}));
codealchemist_log_type_pre('-1763176288040397274', ({}));
function Split5Setup(){
codealchemist_log_type_pre('-8084886703000221054', ({}));
(re) = /[Cz]/;
codealchemist_log_type_post('-8084886703000221054', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-4462442496304244118', ({}));
(str) = "";
codealchemist_log_type_post('-4462442496304244118', ({v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-1763176288040397274', ({}));
codealchemist_log_type_pre('-2163726698169737211', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Split6Setup(){
codealchemist_log_type_pre('133569951202473212', ({}));
(re) = /[cZ]/;
codealchemist_log_type_post('133569951202473212', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-2163726698169737211', ({}));
codealchemist_log_type_pre('6177841110763982542', ({}));
function Split7Setup(){
codealchemist_log_type_pre('-550830995145631400', ({}));
(re) = /[A-Za-z\u0080-\u00FF ]/;
codealchemist_log_type_post('-550830995145631400', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-6095483710597734695', ({}));
(str) = "hipopótamo maçã pólen ñ poção água língüa";
codealchemist_log_type_post('-6095483710597734695', ({v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('6177841110763982542', ({}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var benchmarks = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof benchmarks) != ('undefined')) ? (benchmarks) : (undefined)}));
