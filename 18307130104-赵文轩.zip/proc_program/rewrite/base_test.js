load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
codealchemist_log_type_pre('-7265530382583183660', ({}));
var str;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
codealchemist_log_type_pre('-7265530382583183660', ({}));
var re;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('4318727432189937553', ({v1 : ((typeof re) != ('undefined')) ? (re) : (undefined), v2 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
function SimpleTest(){
codealchemist_log_type_pre('-8820446669730036995', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined), v1 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
re.test(str);
codealchemist_log_type_post('-8820446669730036995', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined), v1 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('4318727432189937553', ({}));
codealchemist_log_type_pre('-6354574074603030189', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Test1Setup(){
codealchemist_log_type_pre('-8084886703000221054', ({}));
(re) = /[Cz]/;
codealchemist_log_type_post('-8084886703000221054', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-6354574074603030189', ({}));
codealchemist_log_type_pre('-2163726698169737211', ({v3 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
function Test2Setup(){
codealchemist_log_type_pre('133569951202473212', ({}));
(re) = /[cZ]/;
codealchemist_log_type_post('133569951202473212', ({v0 : ((typeof re) != ('undefined')) ? (re) : (undefined)}));
codealchemist_log_type_pre('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined)}));
(str) = createHaystack();
codealchemist_log_type_post('-2116251575524981513', ({v1 : ((typeof createHaystack) != ('undefined')) ? (createHaystack) : (undefined), v0 : ((typeof str) != ('undefined')) ? (str) : (undefined)}));
}
codealchemist_log_type_post('-2163726698169737211', ({}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var benchmarks = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof benchmarks) != ('undefined')) ? (benchmarks) : (undefined)}));
