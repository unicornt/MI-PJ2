load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('181413251605960821', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('BaselineNaivePromises', [], []);
codealchemist_log_type_post('181413251605960821', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('-3120425829689395125', ({}));
var a, b, c, d, e, f, g, h, i, j, x;
codealchemist_log_type_post('-3120425829689395125', ({v0 : ((typeof a) != ('undefined')) ? (a) : (undefined), v1 : ((typeof b) != ('undefined')) ? (b) : (undefined), v2 : ((typeof c) != ('undefined')) ? (c) : (undefined), v3 : ((typeof d) != ('undefined')) ? (d) : (undefined), v4 : ((typeof e) != ('undefined')) ? (e) : (undefined), v5 : ((typeof f) != ('undefined')) ? (f) : (undefined), v6 : ((typeof g) != ('undefined')) ? (g) : (undefined), v7 : ((typeof h) != ('undefined')) ? (h) : (undefined), v8 : ((typeof i) != ('undefined')) ? (i) : (undefined), v9 : ((typeof j) != ('undefined')) ? (j) : (undefined), v10 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('7168177208154931883', ({}));
function Setup(){
codealchemist_log_type_pre('5143729957139292452', ({}));
(x) = Promise.resolve();
codealchemist_log_type_post('5143729957139292452', ({v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(j) = (function j(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-5459276325814198816', ({v2 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
(i) = (function i(p){
codealchemist_log_type_pre('3855228463183448669', ({v1 : ((typeof j) != ('undefined')) ? (j) : (undefined), v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3855228463183448669 = p.then(j).then(j).then(j).then(j).then(j).then(j).then(j).then(j).then(j).then(j);
codealchemist_log_type_post('3855228463183448669', ({v1 : ((typeof j) != ('undefined')) ? (j) : (undefined), v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3855228463183448669;
});
codealchemist_log_type_post('-5459276325814198816', ({v0 : ((typeof i) != ('undefined')) ? (i) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(h) = (function h(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof h) != ('undefined')) ? (h) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(g) = (function g(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof g) != ('undefined')) ? (g) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(f) = (function f(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof f) != ('undefined')) ? (f) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(e) = (function e(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof e) != ('undefined')) ? (e) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(d) = (function d(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof d) != ('undefined')) ? (d) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(c) = (function c(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof c) != ('undefined')) ? (c) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(b) = (function b(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof b) != ('undefined')) ? (b) : (undefined)}));
codealchemist_log_type_pre('7656729046773269574', ({}));
(a) = (function a(p){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
var temp_3444589576563574513 = p;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof p) != ('undefined')) ? (p) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('7656729046773269574', ({v0 : ((typeof a) != ('undefined')) ? (a) : (undefined)}));
codealchemist_log_type_pre('-7577906835347277920', ({}));
%PerformMicrotaskCheckpoint();
codealchemist_log_type_post('-7577906835347277920', ({}));
}
codealchemist_log_type_post('7168177208154931883', ({}));
codealchemist_log_type_pre('-6689310503718896037', ({v11 : ((typeof a) != ('undefined')) ? (a) : (undefined), v10 : ((typeof b) != ('undefined')) ? (b) : (undefined), v9 : ((typeof c) != ('undefined')) ? (c) : (undefined), v8 : ((typeof d) != ('undefined')) ? (d) : (undefined), v7 : ((typeof e) != ('undefined')) ? (e) : (undefined), v6 : ((typeof f) != ('undefined')) ? (f) : (undefined), v5 : ((typeof g) != ('undefined')) ? (g) : (undefined), v4 : ((typeof h) != ('undefined')) ? (h) : (undefined), v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v2 : ((typeof j) != ('undefined')) ? (j) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
function Basic(){
codealchemist_log_type_pre('6411436564479478209', ({v10 : ((typeof a) != ('undefined')) ? (a) : (undefined), v9 : ((typeof b) != ('undefined')) ? (b) : (undefined), v8 : ((typeof c) != ('undefined')) ? (c) : (undefined), v7 : ((typeof d) != ('undefined')) ? (d) : (undefined), v6 : ((typeof e) != ('undefined')) ? (e) : (undefined), v5 : ((typeof f) != ('undefined')) ? (f) : (undefined), v4 : ((typeof g) != ('undefined')) ? (g) : (undefined), v3 : ((typeof h) != ('undefined')) ? (h) : (undefined), v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof j) != ('undefined')) ? (j) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
x.then(j).then(i).then(h).then(g).then(f).then(e).then(d).then(c).then(b).then(a);
codealchemist_log_type_post('6411436564479478209', ({v10 : ((typeof a) != ('undefined')) ? (a) : (undefined), v9 : ((typeof b) != ('undefined')) ? (b) : (undefined), v8 : ((typeof c) != ('undefined')) ? (c) : (undefined), v7 : ((typeof d) != ('undefined')) ? (d) : (undefined), v6 : ((typeof e) != ('undefined')) ? (e) : (undefined), v5 : ((typeof f) != ('undefined')) ? (f) : (undefined), v4 : ((typeof g) != ('undefined')) ? (g) : (undefined), v3 : ((typeof h) != ('undefined')) ? (h) : (undefined), v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof j) != ('undefined')) ? (j) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('-7577906835347277920', ({}));
%PerformMicrotaskCheckpoint();
codealchemist_log_type_post('-7577906835347277920', ({}));
}
codealchemist_log_type_post('-6689310503718896037', ({}));
