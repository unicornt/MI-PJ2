load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('3005741484085063489', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('ConstructArrayLike', [], []);
codealchemist_log_type_post('3005741484085063489', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var arr = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof arr) != ('undefined')) ? (arr) : (undefined)}));
codealchemist_log_type_pre('7876547255508203412', ({v2 : ((typeof arr) != ('undefined')) ? (arr) : (undefined)}));
function constructor(){
codealchemist_log_type_pre('7653063661367291825', ({v1 : ((typeof arr) != ('undefined')) ? (arr) : (undefined)}));
new Int32Array(arr);
codealchemist_log_type_post('7653063661367291825', ({v1 : ((typeof arr) != ('undefined')) ? (arr) : (undefined)}));
}
codealchemist_log_type_post('7876547255508203412', ({}));
