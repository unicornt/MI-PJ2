load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('-1185833915175458564', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('Constructor', [], []);
codealchemist_log_type_post('-1185833915175458564', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('6779801002734349370', ({}));
function constructor(){
codealchemist_log_type_pre('-541362753993728436', ({}));
new Int32Array(16);
codealchemist_log_type_post('-541362753993728436', ({}));
}
codealchemist_log_type_post('6779801002734349370', ({}));
