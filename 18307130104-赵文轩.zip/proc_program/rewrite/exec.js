load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
load("base_exec.js");
codealchemist_log_type_pre('1226895343169452580', ({v0 : ((typeof createBenchmarkSuite) != ('undefined')) ? (createBenchmarkSuite) : (undefined)}));
createBenchmarkSuite("Exec");
codealchemist_log_type_post('1226895343169452580', ({v0 : ((typeof createBenchmarkSuite) != ('undefined')) ? (createBenchmarkSuite) : (undefined)}));
