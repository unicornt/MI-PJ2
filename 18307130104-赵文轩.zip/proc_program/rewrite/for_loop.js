load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('6984096054000970793', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('Let-Standard', [], []);
codealchemist_log_type_post('6984096054000970793', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('2555551009760434580', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('Var-Standard', [], []);
codealchemist_log_type_post('2555551009760434580', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var x = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var y = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
codealchemist_log_type_pre('5019228213384283871', ({v3 : ((typeof x) != ('undefined')) ? (x) : (undefined), v5 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
function LetLoop(){
codealchemist_log_type_pre('-7444987635282321314', ({}));
"use strict";
codealchemist_log_type_post('-7444987635282321314', ({}));
codealchemist_log_type_pre('7838083884550891431', ({}));
const ret = [];
codealchemist_log_type_post('7838083884550891431', ({v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
codealchemist_log_type_pre('43621044312180377', ({v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined), v3 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
for(let i = 0;(i) < (x.length);i++){
codealchemist_log_type_pre('7024977488286467292', ({v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v2 : ((typeof x) != ('undefined')) ? (x) : (undefined), v1 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
codealchemist_log_type_pre('-1559326611082126773', ({v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v2 : ((typeof x) != ('undefined')) ? (x) : (undefined), v1 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
for(let z = 0;(z) < (y.length);z++){
codealchemist_log_type_pre('-1487958873263648717', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined), v3 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
codealchemist_log_type_pre('7688139112596299874', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined), v3 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
if((x[i]) == (y[z])){
codealchemist_log_type_pre('-2140423632359377820', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('-1158939576976701877', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
ret.push(x[i]);
codealchemist_log_type_post('-1158939576976701877', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
break ;
codealchemist_log_type_post('-2140423632359377820', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
}
codealchemist_log_type_post('7688139112596299874', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined), v3 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
codealchemist_log_type_post('-1487958873263648717', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined), v3 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
}
codealchemist_log_type_post('-1559326611082126773', ({v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v2 : ((typeof x) != ('undefined')) ? (x) : (undefined), v1 : ((typeof y) != ('undefined')) ? (y) : (undefined), v0 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
codealchemist_log_type_post('7024977488286467292', ({v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v2 : ((typeof x) != ('undefined')) ? (x) : (undefined), v1 : ((typeof y) != ('undefined')) ? (y) : (undefined), v0 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
}
codealchemist_log_type_post('43621044312180377', ({v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined), v3 : ((typeof y) != ('undefined')) ? (y) : (undefined), v2 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
var temp_3444589576563574513 = ret;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
return temp_3444589576563574513;
}
codealchemist_log_type_post('5019228213384283871', ({}));
codealchemist_log_type_pre('-3943174582005235599', ({v3 : ((typeof x) != ('undefined')) ? (x) : (undefined), v5 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
function VarLoop(){
codealchemist_log_type_pre('-7444987635282321314', ({}));
"use strict";
codealchemist_log_type_post('-7444987635282321314', ({}));
codealchemist_log_type_pre('7838083884550891431', ({}));
const ret = [];
codealchemist_log_type_post('7838083884550891431', ({v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
codealchemist_log_type_pre('7756410651193787801', ({v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined), v3 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
for(var i = 0;(i) < (x.length);i++){
codealchemist_log_type_pre('4115470352552884852', ({v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v2 : ((typeof x) != ('undefined')) ? (x) : (undefined), v1 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
codealchemist_log_type_pre('2679459618220099794', ({v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v2 : ((typeof x) != ('undefined')) ? (x) : (undefined), v1 : ((typeof y) != ('undefined')) ? (y) : (undefined)}));
for(var z = 0;(z) < (y.length);z++){
codealchemist_log_type_pre('-1487958873263648717', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined), v3 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
codealchemist_log_type_pre('7688139112596299874', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined), v3 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
if((x[i]) == (y[z])){
codealchemist_log_type_pre('-2140423632359377820', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('-1158939576976701877', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
ret.push(x[i]);
codealchemist_log_type_post('-1158939576976701877', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
break ;
codealchemist_log_type_post('-2140423632359377820', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
}
codealchemist_log_type_post('7688139112596299874', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined), v3 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
codealchemist_log_type_post('-1487958873263648717', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v0 : ((typeof x) != ('undefined')) ? (x) : (undefined), v2 : ((typeof y) != ('undefined')) ? (y) : (undefined), v3 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
}
codealchemist_log_type_post('2679459618220099794', ({v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v2 : ((typeof x) != ('undefined')) ? (x) : (undefined), v1 : ((typeof y) != ('undefined')) ? (y) : (undefined), v0 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
codealchemist_log_type_post('4115470352552884852', ({v3 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v2 : ((typeof x) != ('undefined')) ? (x) : (undefined), v1 : ((typeof y) != ('undefined')) ? (y) : (undefined), v0 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
}
codealchemist_log_type_post('7756410651193787801', ({v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v4 : ((typeof ret) != ('undefined')) ? (ret) : (undefined), v1 : ((typeof x) != ('undefined')) ? (x) : (undefined), v3 : ((typeof y) != ('undefined')) ? (y) : (undefined), v2 : ((typeof z) != ('undefined')) ? (z) : (undefined)}));
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
var temp_3444589576563574513 = ret;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
return temp_3444589576563574513;
}
codealchemist_log_type_post('-3943174582005235599', ({}));
