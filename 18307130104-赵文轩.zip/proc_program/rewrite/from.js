load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('955045525725069701', ({v19 : ((typeof DoubleFrom) != ('undefined')) ? (DoubleFrom) : (undefined), v20 : ((typeof DoubleFromSetup) != ('undefined')) ? (DoubleFromSetup) : (undefined), v21 : ((typeof DoubleNoMapFrom) != ('undefined')) ? (DoubleNoMapFrom) : (undefined), v22 : ((typeof DoubleNoMapFromSetup) != ('undefined')) ? (DoubleNoMapFromSetup) : (undefined), v3 : ((typeof MixedCowNoMapFrom) != ('undefined')) ? (MixedCowNoMapFrom) : (undefined), v4 : ((typeof MixedCowNoMapFromSetup) != ('undefined')) ? (MixedCowNoMapFromSetup) : (undefined), v1 : ((typeof MixedFrom) != ('undefined')) ? (MixedFrom) : (undefined), v2 : ((typeof MixedFromSetup) != ('undefined')) ? (MixedFromSetup) : (undefined), v5 : ((typeof MixedNonCowNoMapFrom) != ('undefined')) ? (MixedNonCowNoMapFrom) : (undefined), v6 : ((typeof MixedNonCowNoMapFromSetup) != ('undefined')) ? (MixedNonCowNoMapFromSetup) : (undefined), v9 : ((typeof SmallSmiFrom) != ('undefined')) ? (SmallSmiFrom) : (undefined), v10 : ((typeof SmallSmiFromSetup) != ('undefined')) ? (SmallSmiFromSetup) : (undefined), v11 : ((typeof SmiCowNoMapFrom) != ('undefined')) ? (SmiCowNoMapFrom) : (undefined), v12 : ((typeof SmiCowNoMapFromSetup) != ('undefined')) ? (SmiCowNoMapFromSetup) : (undefined), v7 : ((typeof SmiFrom) != ('undefined')) ? (SmiFrom) : (undefined), v8 : ((typeof SmiFromSetup) != ('undefined')) ? (SmiFromSetup) : (undefined), v15 : ((typeof SmiNoIteratorFrom) != ('undefined')) ? (SmiNoIteratorFrom) : (undefined), v16 : ((typeof SmiNoIteratorFromSetup) != ('undefined')) ? (SmiNoIteratorFromSetup) : (undefined), v13 : ((typeof SmiNonCowNoMapFrom) != ('undefined')) ? (SmiNonCowNoMapFrom) : (undefined), v14 : ((typeof SmiNonCowNoMapFromSetup) != ('undefined')) ? (SmiNonCowNoMapFromSetup) : (undefined), v25 : ((typeof StringCowNoMapFrom) != ('undefined')) ? (StringCowNoMapFrom) : (undefined), v26 : ((typeof StringCowNoMapFromSetup) != ('undefined')) ? (StringCowNoMapFromSetup) : (undefined), v23 : ((typeof StringFrom) != ('undefined')) ? (StringFrom) : (undefined), v24 : ((typeof StringFromSetup) != ('undefined')) ? (StringFromSetup) : (undefined), v27 : ((typeof StringNonCowNoMapFrom) != ('undefined')) ? (StringNonCowNoMapFrom) : (undefined), v28 : ((typeof StringNonCowNoMapFromSetup) != ('undefined')) ? (StringNonCowNoMapFromSetup) : (undefined), v17 : ((typeof TransplantedFrom) != ('undefined')) ? (TransplantedFrom) : (undefined), v18 : ((typeof TransplantedFromSetup) != ('undefined')) ? (TransplantedFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
(()=>{
codealchemist_log_type_pre('-6186030856018844558', ({v1 : ((typeof MixedFrom) != ('undefined')) ? (MixedFrom) : (undefined), v2 : ((typeof MixedFromSetup) != ('undefined')) ? (MixedFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('MixedFrom', 1000, MixedFrom, MixedFromSetup);
codealchemist_log_type_post('-6186030856018844558', ({v1 : ((typeof MixedFrom) != ('undefined')) ? (MixedFrom) : (undefined), v2 : ((typeof MixedFromSetup) != ('undefined')) ? (MixedFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-4727294224088023497', ({v1 : ((typeof MixedCowNoMapFrom) != ('undefined')) ? (MixedCowNoMapFrom) : (undefined), v2 : ((typeof MixedCowNoMapFromSetup) != ('undefined')) ? (MixedCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('MixedCowNoMapFrom', 1000, MixedCowNoMapFrom, MixedCowNoMapFromSetup);
codealchemist_log_type_post('-4727294224088023497', ({v1 : ((typeof MixedCowNoMapFrom) != ('undefined')) ? (MixedCowNoMapFrom) : (undefined), v2 : ((typeof MixedCowNoMapFromSetup) != ('undefined')) ? (MixedCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('3953235274418291237', ({v1 : ((typeof MixedNonCowNoMapFrom) != ('undefined')) ? (MixedNonCowNoMapFrom) : (undefined), v2 : ((typeof MixedNonCowNoMapFromSetup) != ('undefined')) ? (MixedNonCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('MixedNonCowNoMapFrom', 1000, MixedNonCowNoMapFrom, MixedNonCowNoMapFromSetup);
codealchemist_log_type_post('3953235274418291237', ({v1 : ((typeof MixedNonCowNoMapFrom) != ('undefined')) ? (MixedNonCowNoMapFrom) : (undefined), v2 : ((typeof MixedNonCowNoMapFromSetup) != ('undefined')) ? (MixedNonCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('5254089690471661177', ({v1 : ((typeof SmiFrom) != ('undefined')) ? (SmiFrom) : (undefined), v2 : ((typeof SmiFromSetup) != ('undefined')) ? (SmiFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmiFrom', 1000, SmiFrom, SmiFromSetup);
codealchemist_log_type_post('5254089690471661177', ({v1 : ((typeof SmiFrom) != ('undefined')) ? (SmiFrom) : (undefined), v2 : ((typeof SmiFromSetup) != ('undefined')) ? (SmiFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('997486643020981373', ({v1 : ((typeof SmallSmiFrom) != ('undefined')) ? (SmallSmiFrom) : (undefined), v2 : ((typeof SmallSmiFromSetup) != ('undefined')) ? (SmallSmiFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmallSmiFrom', 1000, SmallSmiFrom, SmallSmiFromSetup);
codealchemist_log_type_post('997486643020981373', ({v1 : ((typeof SmallSmiFrom) != ('undefined')) ? (SmallSmiFrom) : (undefined), v2 : ((typeof SmallSmiFromSetup) != ('undefined')) ? (SmallSmiFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('4297988654019495145', ({v1 : ((typeof SmiCowNoMapFrom) != ('undefined')) ? (SmiCowNoMapFrom) : (undefined), v2 : ((typeof SmiCowNoMapFromSetup) != ('undefined')) ? (SmiCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmiCowNoMapFrom', 1000, SmiCowNoMapFrom, SmiCowNoMapFromSetup);
codealchemist_log_type_post('4297988654019495145', ({v1 : ((typeof SmiCowNoMapFrom) != ('undefined')) ? (SmiCowNoMapFrom) : (undefined), v2 : ((typeof SmiCowNoMapFromSetup) != ('undefined')) ? (SmiCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-3426693551429840060', ({v1 : ((typeof SmiNonCowNoMapFrom) != ('undefined')) ? (SmiNonCowNoMapFrom) : (undefined), v2 : ((typeof SmiNonCowNoMapFromSetup) != ('undefined')) ? (SmiNonCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmiNonCowNoMapFrom', 1000, SmiNonCowNoMapFrom, SmiNonCowNoMapFromSetup);
codealchemist_log_type_post('-3426693551429840060', ({v1 : ((typeof SmiNonCowNoMapFrom) != ('undefined')) ? (SmiNonCowNoMapFrom) : (undefined), v2 : ((typeof SmiNonCowNoMapFromSetup) != ('undefined')) ? (SmiNonCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('5772672116433218042', ({v1 : ((typeof SmiNoIteratorFrom) != ('undefined')) ? (SmiNoIteratorFrom) : (undefined), v2 : ((typeof SmiNoIteratorFromSetup) != ('undefined')) ? (SmiNoIteratorFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmiNoIteratorFrom', 1000, SmiNoIteratorFrom, SmiNoIteratorFromSetup);
codealchemist_log_type_post('5772672116433218042', ({v1 : ((typeof SmiNoIteratorFrom) != ('undefined')) ? (SmiNoIteratorFrom) : (undefined), v2 : ((typeof SmiNoIteratorFromSetup) != ('undefined')) ? (SmiNoIteratorFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-5150487220565801290', ({v1 : ((typeof TransplantedFrom) != ('undefined')) ? (TransplantedFrom) : (undefined), v2 : ((typeof TransplantedFromSetup) != ('undefined')) ? (TransplantedFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('TransplantedFrom', 1000, TransplantedFrom, TransplantedFromSetup);
codealchemist_log_type_post('-5150487220565801290', ({v1 : ((typeof TransplantedFrom) != ('undefined')) ? (TransplantedFrom) : (undefined), v2 : ((typeof TransplantedFromSetup) != ('undefined')) ? (TransplantedFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-3005427743124628542', ({v1 : ((typeof DoubleFrom) != ('undefined')) ? (DoubleFrom) : (undefined), v2 : ((typeof DoubleFromSetup) != ('undefined')) ? (DoubleFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('DoubleFrom', 1000, DoubleFrom, DoubleFromSetup);
codealchemist_log_type_post('-3005427743124628542', ({v1 : ((typeof DoubleFrom) != ('undefined')) ? (DoubleFrom) : (undefined), v2 : ((typeof DoubleFromSetup) != ('undefined')) ? (DoubleFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-2916504112138719235', ({v1 : ((typeof DoubleNoMapFrom) != ('undefined')) ? (DoubleNoMapFrom) : (undefined), v2 : ((typeof DoubleNoMapFromSetup) != ('undefined')) ? (DoubleNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('DoubleNoMapFrom', 1000, DoubleNoMapFrom, DoubleNoMapFromSetup);
codealchemist_log_type_post('-2916504112138719235', ({v1 : ((typeof DoubleNoMapFrom) != ('undefined')) ? (DoubleNoMapFrom) : (undefined), v2 : ((typeof DoubleNoMapFromSetup) != ('undefined')) ? (DoubleNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('5546106641050644685', ({v1 : ((typeof StringFrom) != ('undefined')) ? (StringFrom) : (undefined), v2 : ((typeof StringFromSetup) != ('undefined')) ? (StringFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('StringFrom', 1000, StringFrom, StringFromSetup);
codealchemist_log_type_post('5546106641050644685', ({v1 : ((typeof StringFrom) != ('undefined')) ? (StringFrom) : (undefined), v2 : ((typeof StringFromSetup) != ('undefined')) ? (StringFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('5826573736998008300', ({v1 : ((typeof StringCowNoMapFrom) != ('undefined')) ? (StringCowNoMapFrom) : (undefined), v2 : ((typeof StringCowNoMapFromSetup) != ('undefined')) ? (StringCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('StringCowNoMapFrom', 1000, StringCowNoMapFrom, StringCowNoMapFromSetup);
codealchemist_log_type_post('5826573736998008300', ({v1 : ((typeof StringCowNoMapFrom) != ('undefined')) ? (StringCowNoMapFrom) : (undefined), v2 : ((typeof StringCowNoMapFromSetup) != ('undefined')) ? (StringCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('5976460577264200881', ({v1 : ((typeof StringNonCowNoMapFrom) != ('undefined')) ? (StringNonCowNoMapFrom) : (undefined), v2 : ((typeof StringNonCowNoMapFromSetup) != ('undefined')) ? (StringNonCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('StringNonCowNoMapFrom', 1000, StringNonCowNoMapFrom, StringNonCowNoMapFromSetup);
codealchemist_log_type_post('5976460577264200881', ({v1 : ((typeof StringNonCowNoMapFrom) != ('undefined')) ? (StringNonCowNoMapFrom) : (undefined), v2 : ((typeof StringNonCowNoMapFromSetup) != ('undefined')) ? (StringNonCowNoMapFromSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-857060939854026304', ({}));
function ArrayLike(){
}
codealchemist_log_type_post('-857060939854026304', ({}));
codealchemist_log_type_pre('-6681604973647538989', ({v0 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined)}));
(ArrayLike.from) = Array.from;
codealchemist_log_type_post('-6681604973647538989', ({v0 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined)}));
codealchemist_log_type_pre('-7265530382583183660', ({}));
var arg;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
codealchemist_log_type_pre('-7265530382583183660', ({}));
var result;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
codealchemist_log_type_pre('-7265530382583183660', ({}));
var func;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var smi_array_Cow = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
codealchemist_log_type_pre('-8809829952621148529', ({v2 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
var smi_array = Array.from(smi_array_Cow);
codealchemist_log_type_post('-8809829952621148529', ({v0 : ((typeof smi_array) != ('undefined')) ? (smi_array) : (undefined), v2 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
codealchemist_log_type_pre('8689186068306206095', ({v0 : ((typeof smi_array) != ('undefined')) ? (smi_array) : (undefined)}));
(smi_array[0]) = 1;
codealchemist_log_type_post('8689186068306206095', ({v0 : ((typeof smi_array) != ('undefined')) ? (smi_array) : (undefined)}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var double_array = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof double_array) != ('undefined')) ? (double_array) : (undefined)}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var string_array_Cow = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
codealchemist_log_type_pre('-8809829952621148529', ({v2 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
var string_array = Array.from(string_array_Cow);
codealchemist_log_type_post('-8809829952621148529', ({v0 : ((typeof string_array) != ('undefined')) ? (string_array) : (undefined), v2 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
codealchemist_log_type_pre('-3050186373707494311', ({v0 : ((typeof string_array) != ('undefined')) ? (string_array) : (undefined)}));
(string_array[0]) = 'a';
codealchemist_log_type_post('-3050186373707494311', ({v0 : ((typeof string_array) != ('undefined')) ? (string_array) : (undefined)}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var mixed_array_Cow = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
codealchemist_log_type_pre('-8809829952621148529', ({v2 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
var mixed_array = Array.from(mixed_array_Cow);
codealchemist_log_type_post('-8809829952621148529', ({v0 : ((typeof mixed_array) != ('undefined')) ? (mixed_array) : (undefined), v2 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
codealchemist_log_type_pre('8689186068306206095', ({v0 : ((typeof mixed_array) != ('undefined')) ? (mixed_array) : (undefined)}));
(mixed_array[0]) = 1;
codealchemist_log_type_post('8689186068306206095', ({v0 : ((typeof mixed_array) != ('undefined')) ? (mixed_array) : (undefined)}));
codealchemist_log_type_pre('1676475267901865125', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v4 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
function SmallSmiFrom(){
codealchemist_log_type_pre('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
(result) = Array.from(arg, func);
codealchemist_log_type_post('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('1676475267901865125', ({}));
codealchemist_log_type_pre('-1887736546786337619', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
function SmiCowNoMapFrom(){
codealchemist_log_type_pre('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
(result) = Array.from(arg);
codealchemist_log_type_post('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-1887736546786337619', ({}));
codealchemist_log_type_pre('-1887736546786337619', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
function SmiNonCowNoMapFrom(){
codealchemist_log_type_pre('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
(result) = Array.from(arg);
codealchemist_log_type_post('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-1887736546786337619', ({}));
codealchemist_log_type_pre('1676475267901865125', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v4 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
function SmiFrom(){
codealchemist_log_type_pre('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
(result) = Array.from(arg, func);
codealchemist_log_type_post('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('1676475267901865125', ({}));
codealchemist_log_type_pre('1676475267901865125', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v4 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
function SmiNoIteratorFrom(){
codealchemist_log_type_pre('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
(result) = Array.from(arg, func);
codealchemist_log_type_post('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('1676475267901865125', ({}));
codealchemist_log_type_pre('4232816860737795217', ({v2 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined), v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v4 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
function TransplantedFrom(){
codealchemist_log_type_pre('318901352443787602', ({v1 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined), v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
(result) = ArrayLike.from(arg, func);
codealchemist_log_type_post('318901352443787602', ({v1 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined), v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('4232816860737795217', ({}));
codealchemist_log_type_pre('1676475267901865125', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v4 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
function DoubleFrom(){
codealchemist_log_type_pre('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
(result) = Array.from(arg, func);
codealchemist_log_type_post('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('1676475267901865125', ({}));
codealchemist_log_type_pre('-1887736546786337619', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
function DoubleNoMapFrom(){
codealchemist_log_type_pre('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
(result) = Array.from(arg);
codealchemist_log_type_post('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-1887736546786337619', ({}));
codealchemist_log_type_pre('1676475267901865125', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v4 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
function StringFrom(){
codealchemist_log_type_pre('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
(result) = Array.from(arg, func);
codealchemist_log_type_post('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('1676475267901865125', ({}));
codealchemist_log_type_pre('-1887736546786337619', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
function StringCowNoMapFrom(){
codealchemist_log_type_pre('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
(result) = Array.from(arg);
codealchemist_log_type_post('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-1887736546786337619', ({}));
codealchemist_log_type_pre('-1887736546786337619', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
function StringNonCowNoMapFrom(){
codealchemist_log_type_pre('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
(result) = Array.from(arg);
codealchemist_log_type_post('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-1887736546786337619', ({}));
codealchemist_log_type_pre('1676475267901865125', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v4 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
function MixedFrom(){
codealchemist_log_type_pre('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
(result) = Array.from(arg, func);
codealchemist_log_type_post('-3275573878547947194', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v3 : ((typeof func) != ('undefined')) ? (func) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('1676475267901865125', ({}));
codealchemist_log_type_pre('-1887736546786337619', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
function MixedCowNoMapFrom(){
codealchemist_log_type_pre('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
(result) = Array.from(arg);
codealchemist_log_type_post('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-1887736546786337619', ({}));
codealchemist_log_type_pre('-1887736546786337619', ({v3 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
function MixedNonCowNoMapFrom(){
codealchemist_log_type_pre('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
(result) = Array.from(arg);
codealchemist_log_type_post('-1888437439891697379', ({v2 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-1887736546786337619', ({}));
codealchemist_log_type_pre('2454814517040753578', ({}));
function SmallSmiFromSetup(){
codealchemist_log_type_pre('9122289758769610095', ({}));
(func) = ((v, i)=>(v) + (i));
codealchemist_log_type_post('9122289758769610095', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('1816577267335569864', ({}));
(arg) = [];
codealchemist_log_type_post('1816577267335569864', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined)}));
}
codealchemist_log_type_post('2454814517040753578', ({}));
codealchemist_log_type_pre('-564816741489818099', ({v4 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
function SmiCowNoMapFromSetup(){
codealchemist_log_type_pre('-8352238078044404304', ({}));
(func) = undefined;
codealchemist_log_type_post('-8352238078044404304', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
(arg) = smi_array_Cow;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
}
codealchemist_log_type_post('-564816741489818099', ({}));
codealchemist_log_type_pre('-564816741489818099', ({v4 : ((typeof smi_array) != ('undefined')) ? (smi_array) : (undefined)}));
function SmiNonCowNoMapFromSetup(){
codealchemist_log_type_pre('-8352238078044404304', ({}));
(func) = undefined;
codealchemist_log_type_post('-8352238078044404304', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof smi_array) != ('undefined')) ? (smi_array) : (undefined)}));
(arg) = smi_array;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof smi_array) != ('undefined')) ? (smi_array) : (undefined)}));
}
codealchemist_log_type_post('-564816741489818099', ({}));
codealchemist_log_type_pre('5847242020757039068', ({v5 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
function SmiFromSetup(){
codealchemist_log_type_pre('9122289758769610095', ({}));
(func) = ((v, i)=>(v) + (i));
codealchemist_log_type_post('9122289758769610095', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
(arg) = smi_array_Cow;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
}
codealchemist_log_type_post('5847242020757039068', ({}));
codealchemist_log_type_pre('138909502082935757', ({v5 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
function SmiNoIteratorFromSetup(){
codealchemist_log_type_pre('9122289758769610095', ({}));
(func) = ((v, i)=>(v) + (i));
codealchemist_log_type_post('9122289758769610095', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
(array) = smi_array_Cow;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof array) != ('undefined')) ? (array) : (undefined), v1 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
codealchemist_log_type_pre('-2731544983694493491', ({v1 : ((typeof array) != ('undefined')) ? (array) : (undefined)}));
(arg) = ({length : array.length});
codealchemist_log_type_post('-2731544983694493491', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof array) != ('undefined')) ? (array) : (undefined)}));
codealchemist_log_type_pre('-4450185281339364517', ({v1 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v2 : ((typeof array) != ('undefined')) ? (array) : (undefined)}));
Object.assign(arg, array);
codealchemist_log_type_post('-4450185281339364517', ({v1 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v2 : ((typeof array) != ('undefined')) ? (array) : (undefined)}));
}
codealchemist_log_type_post('138909502082935757', ({}));
codealchemist_log_type_pre('5847242020757039068', ({v5 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
function TransplantedFromSetup(){
codealchemist_log_type_pre('9122289758769610095', ({}));
(func) = ((v, i)=>(v) + (i));
codealchemist_log_type_post('9122289758769610095', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
(arg) = smi_array_Cow;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof smi_array_Cow) != ('undefined')) ? (smi_array_Cow) : (undefined)}));
}
codealchemist_log_type_post('5847242020757039068', ({}));
codealchemist_log_type_pre('5847242020757039068', ({v5 : ((typeof double_array) != ('undefined')) ? (double_array) : (undefined)}));
function DoubleFromSetup(){
codealchemist_log_type_pre('9122289758769610095', ({}));
(func) = ((v, i)=>(v) + (i));
codealchemist_log_type_post('9122289758769610095', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof double_array) != ('undefined')) ? (double_array) : (undefined)}));
(arg) = double_array;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof double_array) != ('undefined')) ? (double_array) : (undefined)}));
}
codealchemist_log_type_post('5847242020757039068', ({}));
codealchemist_log_type_pre('-564816741489818099', ({v4 : ((typeof double_array) != ('undefined')) ? (double_array) : (undefined)}));
function DoubleNoMapFromSetup(){
codealchemist_log_type_pre('-8352238078044404304', ({}));
(func) = undefined;
codealchemist_log_type_post('-8352238078044404304', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof double_array) != ('undefined')) ? (double_array) : (undefined)}));
(arg) = double_array;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof double_array) != ('undefined')) ? (double_array) : (undefined)}));
}
codealchemist_log_type_post('-564816741489818099', ({}));
codealchemist_log_type_pre('5847242020757039068', ({v5 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
function StringFromSetup(){
codealchemist_log_type_pre('9122289758769610095', ({}));
(func) = ((v, i)=>(v) + (i));
codealchemist_log_type_post('9122289758769610095', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
(arg) = string_array_Cow;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
}
codealchemist_log_type_post('5847242020757039068', ({}));
codealchemist_log_type_pre('-564816741489818099', ({v4 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
function StringCowNoMapFromSetup(){
codealchemist_log_type_pre('-8352238078044404304', ({}));
(func) = undefined;
codealchemist_log_type_post('-8352238078044404304', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
(arg) = string_array_Cow;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof string_array_Cow) != ('undefined')) ? (string_array_Cow) : (undefined)}));
}
codealchemist_log_type_post('-564816741489818099', ({}));
codealchemist_log_type_pre('-564816741489818099', ({v4 : ((typeof string_array) != ('undefined')) ? (string_array) : (undefined)}));
function StringNonCowNoMapFromSetup(){
codealchemist_log_type_pre('-8352238078044404304', ({}));
(func) = undefined;
codealchemist_log_type_post('-8352238078044404304', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof string_array) != ('undefined')) ? (string_array) : (undefined)}));
(arg) = string_array;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof string_array) != ('undefined')) ? (string_array) : (undefined)}));
}
codealchemist_log_type_post('-564816741489818099', ({}));
codealchemist_log_type_pre('5847242020757039068', ({v5 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
function MixedFromSetup(){
codealchemist_log_type_pre('9122289758769610095', ({}));
(func) = ((v, i)=>(v) + (i));
codealchemist_log_type_post('9122289758769610095', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
(arg) = mixed_array_Cow;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
}
codealchemist_log_type_post('5847242020757039068', ({}));
codealchemist_log_type_pre('-564816741489818099', ({v4 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
function MixedCowNoMapFromSetup(){
codealchemist_log_type_pre('-8352238078044404304', ({}));
(func) = undefined;
codealchemist_log_type_post('-8352238078044404304', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
(arg) = mixed_array_Cow;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof mixed_array_Cow) != ('undefined')) ? (mixed_array_Cow) : (undefined)}));
}
codealchemist_log_type_post('-564816741489818099', ({}));
codealchemist_log_type_pre('-564816741489818099', ({v4 : ((typeof mixed_array) != ('undefined')) ? (mixed_array) : (undefined)}));
function MixedNonCowNoMapFromSetup(){
codealchemist_log_type_pre('-8352238078044404304', ({}));
(func) = undefined;
codealchemist_log_type_post('-8352238078044404304', ({v0 : ((typeof func) != ('undefined')) ? (func) : (undefined)}));
codealchemist_log_type_pre('670706250746082504', ({v1 : ((typeof mixed_array) != ('undefined')) ? (mixed_array) : (undefined)}));
(arg) = mixed_array;
codealchemist_log_type_post('670706250746082504', ({v0 : ((typeof arg) != ('undefined')) ? (arg) : (undefined), v1 : ((typeof mixed_array) != ('undefined')) ? (mixed_array) : (undefined)}));
}
codealchemist_log_type_post('-564816741489818099', ({}));
})();
codealchemist_log_type_post('955045525725069701', ({}));
