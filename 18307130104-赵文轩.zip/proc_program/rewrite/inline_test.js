load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('-8282507737489067949', ({}));
function ConstTest(){
codealchemist_log_type_pre('-1099343064968313356', ({}));
/[Cz]/.test("abCdefgzabCdefgzabCdefgzabCdefgzabCdefgzabCdefgzabCdefgzabCdefgz");
codealchemist_log_type_post('-1099343064968313356', ({}));
}
codealchemist_log_type_post('-8282507737489067949', ({}));
codealchemist_log_type_pre('3651511139527942434', ({}));
const cre = /[Cz]/;
codealchemist_log_type_post('3651511139527942434', ({v0 : ((typeof cre) != ('undefined')) ? (cre) : (undefined)}));
codealchemist_log_type_pre('4035762650185335103', ({v1 : ((typeof cre) != ('undefined')) ? (cre) : (undefined)}));
function GlobalConstTest(){
codealchemist_log_type_pre('4612552703427048578', ({v0 : ((typeof cre) != ('undefined')) ? (cre) : (undefined)}));
cre.test("abCdefgzabCdefgzabCdefgzabCdefgzabCdefgzabCdefgzabCdefgzabCdefgz");
codealchemist_log_type_post('4612552703427048578', ({v0 : ((typeof cre) != ('undefined')) ? (cre) : (undefined)}));
}
codealchemist_log_type_post('4035762650185335103', ({}));
codealchemist_log_type_pre('-2873575392672305138', ({}));
var benchmarks = [];
codealchemist_log_type_post('-2873575392672305138', ({v0 : ((typeof benchmarks) != ('undefined')) ? (benchmarks) : (undefined)}));
codealchemist_log_type_pre('-4637935062383788620', ({v0 : ((typeof createBenchmarkSuite) != ('undefined')) ? (createBenchmarkSuite) : (undefined)}));
createBenchmarkSuite("InlineTest");
codealchemist_log_type_post('-4637935062383788620', ({v0 : ((typeof createBenchmarkSuite) != ('undefined')) ? (createBenchmarkSuite) : (undefined)}));
