load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load('join.js');
codealchemist_log_type_pre('7333010020986986767', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v1 : ((typeof CreateBenchmarks) != ('undefined')) ? (CreateBenchmarks) : (undefined), v2 : ((typeof typedArrayFloatConstructors) != ('undefined')) ? (typedArrayFloatConstructors) : (undefined)}));
new BenchmarkSuite('JoinWithSeparatorFloatTypes', [], CreateBenchmarks(typedArrayFloatConstructors, true));
codealchemist_log_type_post('7333010020986986767', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v1 : ((typeof CreateBenchmarks) != ('undefined')) ? (CreateBenchmarks) : (undefined), v2 : ((typeof typedArrayFloatConstructors) != ('undefined')) ? (typedArrayFloatConstructors) : (undefined)}));
