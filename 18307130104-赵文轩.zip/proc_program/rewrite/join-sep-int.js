load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load('join.js');
codealchemist_log_type_pre('1586784728061524117', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v1 : ((typeof CreateBenchmarks) != ('undefined')) ? (CreateBenchmarks) : (undefined), v2 : ((typeof typedArrayIntConstructors) != ('undefined')) ? (typedArrayIntConstructors) : (undefined)}));
new BenchmarkSuite('JoinWithSeparatorIntTypes', [], CreateBenchmarks(typedArrayIntConstructors, true));
codealchemist_log_type_post('1586784728061524117', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v1 : ((typeof CreateBenchmarks) != ('undefined')) ? (CreateBenchmarks) : (undefined), v2 : ((typeof typedArrayIntConstructors) != ('undefined')) ? (typedArrayIntConstructors) : (undefined)}));
