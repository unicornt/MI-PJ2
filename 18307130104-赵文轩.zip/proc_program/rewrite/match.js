load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
load("base_match.js");
codealchemist_log_type_pre('-8015614101609753715', ({v0 : ((typeof createBenchmarkSuite) != ('undefined')) ? (createBenchmarkSuite) : (undefined)}));
createBenchmarkSuite("Match");
codealchemist_log_type_post('-8015614101609753715', ({v0 : ((typeof createBenchmarkSuite) != ('undefined')) ? (createBenchmarkSuite) : (undefined)}));
