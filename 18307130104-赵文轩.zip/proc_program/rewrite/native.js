load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('5781993936679345602', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('Native', [], []);
codealchemist_log_type_post('5781993936679345602', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('-3120425829689395125', ({}));
var a, b, c, d, e, f, g, h, i, j, x;
codealchemist_log_type_post('-3120425829689395125', ({v0 : ((typeof a) != ('undefined')) ? (a) : (undefined), v1 : ((typeof b) != ('undefined')) ? (b) : (undefined), v2 : ((typeof c) != ('undefined')) ? (c) : (undefined), v3 : ((typeof d) != ('undefined')) ? (d) : (undefined), v4 : ((typeof e) != ('undefined')) ? (e) : (undefined), v5 : ((typeof f) != ('undefined')) ? (f) : (undefined), v6 : ((typeof g) != ('undefined')) ? (g) : (undefined), v7 : ((typeof h) != ('undefined')) ? (h) : (undefined), v8 : ((typeof i) != ('undefined')) ? (i) : (undefined), v9 : ((typeof j) != ('undefined')) ? (j) : (undefined), v10 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('6755027274567869880', ({}));
function Setup(){
codealchemist_log_type_pre('5143729957139292452', ({}));
(x) = Promise.resolve();
codealchemist_log_type_post('5143729957139292452', ({v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
codealchemist_log_type_pre('-617122938461508624', ({v1 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
(j) = (async function j(){
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
var temp_3444589576563574513 = x;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof x) != ('undefined')) ? (x) : (undefined)}));
return temp_3444589576563574513;
});
codealchemist_log_type_post('-617122938461508624', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('1097836632444961982', ({v1 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
(i) = (async function i(){
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
await j();
codealchemist_log_type_post('-7860448145607143165', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
var temp_2196234077404683449 = j();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof j) != ('undefined')) ? (j) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('1097836632444961982', ({v0 : ((typeof i) != ('undefined')) ? (i) : (undefined)}));
codealchemist_log_type_pre('3068166406755398776', ({v1 : ((typeof i) != ('undefined')) ? (i) : (undefined)}));
(h) = (async function h(){
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof i) != ('undefined')) ? (i) : (undefined)}));
var temp_2196234077404683449 = i();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof i) != ('undefined')) ? (i) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('3068166406755398776', ({v0 : ((typeof h) != ('undefined')) ? (h) : (undefined)}));
codealchemist_log_type_pre('3068166406755398776', ({v1 : ((typeof h) != ('undefined')) ? (h) : (undefined)}));
(g) = (async function g(){
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof h) != ('undefined')) ? (h) : (undefined)}));
var temp_2196234077404683449 = h();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof h) != ('undefined')) ? (h) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('3068166406755398776', ({v0 : ((typeof g) != ('undefined')) ? (g) : (undefined)}));
codealchemist_log_type_pre('3068166406755398776', ({v1 : ((typeof g) != ('undefined')) ? (g) : (undefined)}));
(f) = (async function f(){
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof g) != ('undefined')) ? (g) : (undefined)}));
var temp_2196234077404683449 = g();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof g) != ('undefined')) ? (g) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('3068166406755398776', ({v0 : ((typeof f) != ('undefined')) ? (f) : (undefined)}));
codealchemist_log_type_pre('3068166406755398776', ({v1 : ((typeof f) != ('undefined')) ? (f) : (undefined)}));
(e) = (async function e(){
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof f) != ('undefined')) ? (f) : (undefined)}));
var temp_2196234077404683449 = f();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof f) != ('undefined')) ? (f) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('3068166406755398776', ({v0 : ((typeof e) != ('undefined')) ? (e) : (undefined)}));
codealchemist_log_type_pre('3068166406755398776', ({v1 : ((typeof e) != ('undefined')) ? (e) : (undefined)}));
(d) = (async function d(){
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof e) != ('undefined')) ? (e) : (undefined)}));
var temp_2196234077404683449 = e();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof e) != ('undefined')) ? (e) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('3068166406755398776', ({v0 : ((typeof d) != ('undefined')) ? (d) : (undefined)}));
codealchemist_log_type_pre('3068166406755398776', ({v1 : ((typeof d) != ('undefined')) ? (d) : (undefined)}));
(c) = (async function c(){
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof d) != ('undefined')) ? (d) : (undefined)}));
var temp_2196234077404683449 = d();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof d) != ('undefined')) ? (d) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('3068166406755398776', ({v0 : ((typeof c) != ('undefined')) ? (c) : (undefined)}));
codealchemist_log_type_pre('3068166406755398776', ({v1 : ((typeof c) != ('undefined')) ? (c) : (undefined)}));
(b) = (async function b(){
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof c) != ('undefined')) ? (c) : (undefined)}));
var temp_2196234077404683449 = c();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof c) != ('undefined')) ? (c) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('3068166406755398776', ({v0 : ((typeof b) != ('undefined')) ? (b) : (undefined)}));
codealchemist_log_type_pre('3068166406755398776', ({v1 : ((typeof b) != ('undefined')) ? (b) : (undefined)}));
(a) = (async function a(){
codealchemist_log_type_pre('2196234077404683449', ({v0 : ((typeof b) != ('undefined')) ? (b) : (undefined)}));
var temp_2196234077404683449 = b();
codealchemist_log_type_post('2196234077404683449', ({v0 : ((typeof b) != ('undefined')) ? (b) : (undefined)}));
return temp_2196234077404683449;
});
codealchemist_log_type_post('3068166406755398776', ({v0 : ((typeof a) != ('undefined')) ? (a) : (undefined)}));
codealchemist_log_type_pre('-7577906835347277920', ({}));
%PerformMicrotaskCheckpoint();
codealchemist_log_type_post('-7577906835347277920', ({}));
}
codealchemist_log_type_post('6755027274567869880', ({}));
codealchemist_log_type_pre('-3521289898732766750', ({v1 : ((typeof a) != ('undefined')) ? (a) : (undefined)}));
function Basic(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof a) != ('undefined')) ? (a) : (undefined)}));
a();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof a) != ('undefined')) ? (a) : (undefined)}));
codealchemist_log_type_pre('-7577906835347277920', ({}));
%PerformMicrotaskCheckpoint();
codealchemist_log_type_post('-7577906835347277920', ({}));
}
codealchemist_log_type_post('-3521289898732766750', ({}));
