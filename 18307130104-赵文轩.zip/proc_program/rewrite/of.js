load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('2283383799177146975', ({v1 : ((typeof EmptyArrayOf) != ('undefined')) ? (EmptyArrayOf) : (undefined), v2 : ((typeof EmptyArrayOfSetup) != ('undefined')) ? (EmptyArrayOfSetup) : (undefined), v7 : ((typeof LargeSmiArrayOf) != ('undefined')) ? (LargeSmiArrayOf) : (undefined), v8 : ((typeof LargeSmiArrayOfSetup) != ('undefined')) ? (LargeSmiArrayOfSetup) : (undefined), v9 : ((typeof SmallDoubleArrayOf) != ('undefined')) ? (SmallDoubleArrayOf) : (undefined), v10 : ((typeof SmallDoubleArrayOfSetup) != ('undefined')) ? (SmallDoubleArrayOfSetup) : (undefined), v13 : ((typeof SmallMixedArrayOf) != ('undefined')) ? (SmallMixedArrayOf) : (undefined), v14 : ((typeof SmallMixedArrayOfSetup) != ('undefined')) ? (SmallMixedArrayOfSetup) : (undefined), v5 : ((typeof SmallSmiArrayOf) != ('undefined')) ? (SmallSmiArrayOf) : (undefined), v6 : ((typeof SmallSmiArrayOfSetup) != ('undefined')) ? (SmallSmiArrayOfSetup) : (undefined), v11 : ((typeof SmallStringArrayOf) != ('undefined')) ? (SmallStringArrayOf) : (undefined), v12 : ((typeof SmallStringArrayOfSetup) != ('undefined')) ? (SmallStringArrayOfSetup) : (undefined), v3 : ((typeof SmallTransplantedArrayOf) != ('undefined')) ? (SmallTransplantedArrayOf) : (undefined), v4 : ((typeof SmallTransplantedArrayOfSetup) != ('undefined')) ? (SmallTransplantedArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
(()=>{
codealchemist_log_type_pre('3920326145675609108', ({v1 : ((typeof EmptyArrayOf) != ('undefined')) ? (EmptyArrayOf) : (undefined), v2 : ((typeof EmptyArrayOfSetup) != ('undefined')) ? (EmptyArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('EmptyArrayOf', 1000, EmptyArrayOf, EmptyArrayOfSetup);
codealchemist_log_type_post('3920326145675609108', ({v1 : ((typeof EmptyArrayOf) != ('undefined')) ? (EmptyArrayOf) : (undefined), v2 : ((typeof EmptyArrayOfSetup) != ('undefined')) ? (EmptyArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('6941741815258481839', ({v1 : ((typeof SmallTransplantedArrayOf) != ('undefined')) ? (SmallTransplantedArrayOf) : (undefined), v2 : ((typeof SmallTransplantedArrayOfSetup) != ('undefined')) ? (SmallTransplantedArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmallTransplantedArrayOf', 1000, SmallTransplantedArrayOf, SmallTransplantedArrayOfSetup);
codealchemist_log_type_post('6941741815258481839', ({v1 : ((typeof SmallTransplantedArrayOf) != ('undefined')) ? (SmallTransplantedArrayOf) : (undefined), v2 : ((typeof SmallTransplantedArrayOfSetup) != ('undefined')) ? (SmallTransplantedArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('5930751169087141683', ({v1 : ((typeof SmallSmiArrayOf) != ('undefined')) ? (SmallSmiArrayOf) : (undefined), v2 : ((typeof SmallSmiArrayOfSetup) != ('undefined')) ? (SmallSmiArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmallSmiArrayOf', 1000, SmallSmiArrayOf, SmallSmiArrayOfSetup);
codealchemist_log_type_post('5930751169087141683', ({v1 : ((typeof SmallSmiArrayOf) != ('undefined')) ? (SmallSmiArrayOf) : (undefined), v2 : ((typeof SmallSmiArrayOfSetup) != ('undefined')) ? (SmallSmiArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-7946035680438769467', ({v1 : ((typeof LargeSmiArrayOf) != ('undefined')) ? (LargeSmiArrayOf) : (undefined), v2 : ((typeof LargeSmiArrayOfSetup) != ('undefined')) ? (LargeSmiArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('LargeSmiArrayOf', 1000, LargeSmiArrayOf, LargeSmiArrayOfSetup);
codealchemist_log_type_post('-7946035680438769467', ({v1 : ((typeof LargeSmiArrayOf) != ('undefined')) ? (LargeSmiArrayOf) : (undefined), v2 : ((typeof LargeSmiArrayOfSetup) != ('undefined')) ? (LargeSmiArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-2324908343201008310', ({v1 : ((typeof SmallDoubleArrayOf) != ('undefined')) ? (SmallDoubleArrayOf) : (undefined), v2 : ((typeof SmallDoubleArrayOfSetup) != ('undefined')) ? (SmallDoubleArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmallDoubleArrayOf', 1000, SmallDoubleArrayOf, SmallDoubleArrayOfSetup);
codealchemist_log_type_post('-2324908343201008310', ({v1 : ((typeof SmallDoubleArrayOf) != ('undefined')) ? (SmallDoubleArrayOf) : (undefined), v2 : ((typeof SmallDoubleArrayOfSetup) != ('undefined')) ? (SmallDoubleArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('6445683337513557433', ({v1 : ((typeof SmallStringArrayOf) != ('undefined')) ? (SmallStringArrayOf) : (undefined), v2 : ((typeof SmallStringArrayOfSetup) != ('undefined')) ? (SmallStringArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmallStringArrayOf', 1000, SmallStringArrayOf, SmallStringArrayOfSetup);
codealchemist_log_type_post('6445683337513557433', ({v1 : ((typeof SmallStringArrayOf) != ('undefined')) ? (SmallStringArrayOf) : (undefined), v2 : ((typeof SmallStringArrayOfSetup) != ('undefined')) ? (SmallStringArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-487016739275625400', ({v1 : ((typeof SmallMixedArrayOf) != ('undefined')) ? (SmallMixedArrayOf) : (undefined), v2 : ((typeof SmallMixedArrayOfSetup) != ('undefined')) ? (SmallMixedArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('SmallMixedArrayOf', 1000, SmallMixedArrayOf, SmallMixedArrayOfSetup);
codealchemist_log_type_post('-487016739275625400', ({v1 : ((typeof SmallMixedArrayOf) != ('undefined')) ? (SmallMixedArrayOf) : (undefined), v2 : ((typeof SmallMixedArrayOfSetup) != ('undefined')) ? (SmallMixedArrayOfSetup) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('-857060939854026304', ({}));
function ArrayLike(){
}
codealchemist_log_type_post('-857060939854026304', ({}));
codealchemist_log_type_pre('6664700509848159989', ({v0 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined)}));
(ArrayLike.of) = Array.of;
codealchemist_log_type_post('6664700509848159989', ({v0 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined)}));
codealchemist_log_type_pre('1060897881194388189', ({}));
var arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10;
codealchemist_log_type_post('1060897881194388189', ({v0 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v9 : ((typeof arg10) != ('undefined')) ? (arg10) : (undefined), v1 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v2 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v3 : ((typeof arg4) != ('undefined')) ? (arg4) : (undefined), v4 : ((typeof arg5) != ('undefined')) ? (arg5) : (undefined), v5 : ((typeof arg6) != ('undefined')) ? (arg6) : (undefined), v6 : ((typeof arg7) != ('undefined')) ? (arg7) : (undefined), v7 : ((typeof arg8) != ('undefined')) ? (arg8) : (undefined), v8 : ((typeof arg9) != ('undefined')) ? (arg9) : (undefined)}));
codealchemist_log_type_pre('1060897881194388189', ({}));
var arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20;
codealchemist_log_type_post('1060897881194388189', ({v0 : ((typeof arg11) != ('undefined')) ? (arg11) : (undefined), v1 : ((typeof arg12) != ('undefined')) ? (arg12) : (undefined), v2 : ((typeof arg13) != ('undefined')) ? (arg13) : (undefined), v3 : ((typeof arg14) != ('undefined')) ? (arg14) : (undefined), v4 : ((typeof arg15) != ('undefined')) ? (arg15) : (undefined), v5 : ((typeof arg16) != ('undefined')) ? (arg16) : (undefined), v6 : ((typeof arg17) != ('undefined')) ? (arg17) : (undefined), v7 : ((typeof arg18) != ('undefined')) ? (arg18) : (undefined), v8 : ((typeof arg19) != ('undefined')) ? (arg19) : (undefined), v9 : ((typeof arg20) != ('undefined')) ? (arg20) : (undefined)}));
codealchemist_log_type_pre('-7265530382583183660', ({}));
var result;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
codealchemist_log_type_pre('-3577973424056209645', ({}));
function EmptyArrayOf(){
codealchemist_log_type_pre('5759785980841475756', ({}));
(result) = Array.of();
codealchemist_log_type_post('5759785980841475756', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-3577973424056209645', ({}));
codealchemist_log_type_pre('3149100322361021032', ({}));
function BaselineArray(){
codealchemist_log_type_pre('1816577267335569864', ({}));
(result) = [];
codealchemist_log_type_post('1816577267335569864', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('3149100322361021032', ({}));
codealchemist_log_type_pre('65155328775892040', ({v3 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v4 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v5 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
function SmallSmiArrayOf(){
codealchemist_log_type_pre('-6977315277330438379', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
(result) = Array.of(arg1, arg2, arg3);
codealchemist_log_type_post('-6977315277330438379', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('65155328775892040', ({}));
codealchemist_log_type_pre('7268781283046953084', ({v3 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v12 : ((typeof arg10) != ('undefined')) ? (arg10) : (undefined), v13 : ((typeof arg11) != ('undefined')) ? (arg11) : (undefined), v14 : ((typeof arg12) != ('undefined')) ? (arg12) : (undefined), v15 : ((typeof arg13) != ('undefined')) ? (arg13) : (undefined), v16 : ((typeof arg14) != ('undefined')) ? (arg14) : (undefined), v17 : ((typeof arg15) != ('undefined')) ? (arg15) : (undefined), v18 : ((typeof arg16) != ('undefined')) ? (arg16) : (undefined), v19 : ((typeof arg17) != ('undefined')) ? (arg17) : (undefined), v20 : ((typeof arg18) != ('undefined')) ? (arg18) : (undefined), v21 : ((typeof arg19) != ('undefined')) ? (arg19) : (undefined), v4 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v22 : ((typeof arg20) != ('undefined')) ? (arg20) : (undefined), v5 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v6 : ((typeof arg4) != ('undefined')) ? (arg4) : (undefined), v7 : ((typeof arg5) != ('undefined')) ? (arg5) : (undefined), v8 : ((typeof arg6) != ('undefined')) ? (arg6) : (undefined), v9 : ((typeof arg7) != ('undefined')) ? (arg7) : (undefined), v10 : ((typeof arg8) != ('undefined')) ? (arg8) : (undefined), v11 : ((typeof arg9) != ('undefined')) ? (arg9) : (undefined)}));
function LargeSmiArrayOf(){
codealchemist_log_type_pre('-3326093290148848469', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v11 : ((typeof arg10) != ('undefined')) ? (arg10) : (undefined), v12 : ((typeof arg11) != ('undefined')) ? (arg11) : (undefined), v13 : ((typeof arg12) != ('undefined')) ? (arg12) : (undefined), v14 : ((typeof arg13) != ('undefined')) ? (arg13) : (undefined), v15 : ((typeof arg14) != ('undefined')) ? (arg14) : (undefined), v16 : ((typeof arg15) != ('undefined')) ? (arg15) : (undefined), v17 : ((typeof arg16) != ('undefined')) ? (arg16) : (undefined), v18 : ((typeof arg17) != ('undefined')) ? (arg17) : (undefined), v19 : ((typeof arg18) != ('undefined')) ? (arg18) : (undefined), v20 : ((typeof arg19) != ('undefined')) ? (arg19) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v21 : ((typeof arg20) != ('undefined')) ? (arg20) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v5 : ((typeof arg4) != ('undefined')) ? (arg4) : (undefined), v6 : ((typeof arg5) != ('undefined')) ? (arg5) : (undefined), v7 : ((typeof arg6) != ('undefined')) ? (arg6) : (undefined), v8 : ((typeof arg7) != ('undefined')) ? (arg7) : (undefined), v9 : ((typeof arg8) != ('undefined')) ? (arg8) : (undefined), v10 : ((typeof arg9) != ('undefined')) ? (arg9) : (undefined)}));
(result) = Array.of(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20);
codealchemist_log_type_post('-3326093290148848469', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v11 : ((typeof arg10) != ('undefined')) ? (arg10) : (undefined), v12 : ((typeof arg11) != ('undefined')) ? (arg11) : (undefined), v13 : ((typeof arg12) != ('undefined')) ? (arg12) : (undefined), v14 : ((typeof arg13) != ('undefined')) ? (arg13) : (undefined), v15 : ((typeof arg14) != ('undefined')) ? (arg14) : (undefined), v16 : ((typeof arg15) != ('undefined')) ? (arg15) : (undefined), v17 : ((typeof arg16) != ('undefined')) ? (arg16) : (undefined), v18 : ((typeof arg17) != ('undefined')) ? (arg17) : (undefined), v19 : ((typeof arg18) != ('undefined')) ? (arg18) : (undefined), v20 : ((typeof arg19) != ('undefined')) ? (arg19) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v21 : ((typeof arg20) != ('undefined')) ? (arg20) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v5 : ((typeof arg4) != ('undefined')) ? (arg4) : (undefined), v6 : ((typeof arg5) != ('undefined')) ? (arg5) : (undefined), v7 : ((typeof arg6) != ('undefined')) ? (arg6) : (undefined), v8 : ((typeof arg7) != ('undefined')) ? (arg7) : (undefined), v9 : ((typeof arg8) != ('undefined')) ? (arg8) : (undefined), v10 : ((typeof arg9) != ('undefined')) ? (arg9) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('7268781283046953084', ({}));
codealchemist_log_type_pre('-5090128225838209369', ({v2 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined), v3 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v4 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v5 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
function SmallTransplantedArrayOf(){
codealchemist_log_type_pre('2019739664019792707', ({v1 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined), v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
(result) = ArrayLike.of(arg1, arg2, arg3);
codealchemist_log_type_post('2019739664019792707', ({v1 : ((typeof ArrayLike) != ('undefined')) ? (ArrayLike) : (undefined), v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('-5090128225838209369', ({}));
codealchemist_log_type_pre('65155328775892040', ({v3 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v4 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v5 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
function SmallDoubleArrayOf(){
codealchemist_log_type_pre('-6977315277330438379', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
(result) = Array.of(arg1, arg2, arg3);
codealchemist_log_type_post('-6977315277330438379', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('65155328775892040', ({}));
codealchemist_log_type_pre('65155328775892040', ({v3 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v4 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v5 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
function SmallStringArrayOf(){
codealchemist_log_type_pre('-6977315277330438379', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
(result) = Array.of(arg1, arg2, arg3);
codealchemist_log_type_post('-6977315277330438379', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('65155328775892040', ({}));
codealchemist_log_type_pre('65155328775892040', ({v3 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v4 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v5 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
function SmallMixedArrayOf(){
codealchemist_log_type_pre('-6977315277330438379', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
(result) = Array.of(arg1, arg2, arg3);
codealchemist_log_type_post('-6977315277330438379', ({v2 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined), v3 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined), v4 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined), v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
}
codealchemist_log_type_post('65155328775892040', ({}));
codealchemist_log_type_pre('-857060939854026304', ({}));
function EmptyArrayOfSetup(){
}
codealchemist_log_type_post('-857060939854026304', ({}));
codealchemist_log_type_pre('-8600344734606278326', ({}));
function BaselineArraySetup(){
codealchemist_log_type_pre('-8110102381441109808', ({}));
(arg1) = 1;
codealchemist_log_type_post('-8110102381441109808', ({v0 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined)}));
codealchemist_log_type_pre('5404934103464501484', ({}));
(arg2) = 2;
codealchemist_log_type_post('5404934103464501484', ({v0 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined)}));
codealchemist_log_type_pre('-2883320476094799205', ({}));
(arg3) = 3;
codealchemist_log_type_post('-2883320476094799205', ({v0 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
}
codealchemist_log_type_post('-8600344734606278326', ({}));
codealchemist_log_type_pre('-8600344734606278326', ({}));
function SmallSmiArrayOfSetup(){
codealchemist_log_type_pre('-8110102381441109808', ({}));
(arg1) = 1;
codealchemist_log_type_post('-8110102381441109808', ({v0 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined)}));
codealchemist_log_type_pre('5404934103464501484', ({}));
(arg2) = 2;
codealchemist_log_type_post('5404934103464501484', ({v0 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined)}));
codealchemist_log_type_pre('-2883320476094799205', ({}));
(arg3) = 3;
codealchemist_log_type_post('-2883320476094799205', ({v0 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
}
codealchemist_log_type_post('-8600344734606278326', ({}));
codealchemist_log_type_pre('-8600344734606278326', ({}));
function SmallTransplantedArrayOfSetup(){
codealchemist_log_type_pre('-8110102381441109808', ({}));
(arg1) = 1;
codealchemist_log_type_post('-8110102381441109808', ({v0 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined)}));
codealchemist_log_type_pre('5404934103464501484', ({}));
(arg2) = 2;
codealchemist_log_type_post('5404934103464501484', ({v0 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined)}));
codealchemist_log_type_pre('-2883320476094799205', ({}));
(arg3) = 3;
codealchemist_log_type_post('-2883320476094799205', ({v0 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
}
codealchemist_log_type_post('-8600344734606278326', ({}));
codealchemist_log_type_pre('-936030204445983205', ({}));
function SmallDoubleArrayOfSetup(){
codealchemist_log_type_pre('4279561429437631768', ({}));
(arg1) = 1.5;
codealchemist_log_type_post('4279561429437631768', ({v0 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined)}));
codealchemist_log_type_pre('-9030948170701601069', ({}));
(arg2) = 2.5;
codealchemist_log_type_post('-9030948170701601069', ({v0 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined)}));
codealchemist_log_type_pre('1807324777604530230', ({}));
(arg3) = 3.5;
codealchemist_log_type_post('1807324777604530230', ({v0 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
}
codealchemist_log_type_post('-936030204445983205', ({}));
codealchemist_log_type_pre('-4750761124774674993', ({}));
function SmallStringArrayOfSetup(){
codealchemist_log_type_pre('-9137444873135416059', ({}));
(arg1) = 'cat';
codealchemist_log_type_post('-9137444873135416059', ({v0 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined)}));
codealchemist_log_type_pre('5347823012865774973', ({}));
(arg2) = 'dog';
codealchemist_log_type_post('5347823012865774973', ({v0 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined)}));
codealchemist_log_type_pre('-4093846353670161353', ({}));
(arg3) = 'giraffe';
codealchemist_log_type_post('-4093846353670161353', ({v0 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
}
codealchemist_log_type_post('-4750761124774674993', ({}));
codealchemist_log_type_pre('-9213025172935073556', ({}));
function SmallMixedArrayOfSetup(){
codealchemist_log_type_pre('-8110102381441109808', ({}));
(arg1) = 1;
codealchemist_log_type_post('-8110102381441109808', ({v0 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined)}));
codealchemist_log_type_pre('-9030948170701601069', ({}));
(arg2) = 2.5;
codealchemist_log_type_post('-9030948170701601069', ({v0 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined)}));
codealchemist_log_type_pre('-4093846353670161353', ({}));
(arg3) = 'giraffe';
codealchemist_log_type_post('-4093846353670161353', ({v0 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
}
codealchemist_log_type_post('-9213025172935073556', ({}));
codealchemist_log_type_pre('-356543566816654177', ({}));
function LargeSmiArrayOfSetup(){
codealchemist_log_type_pre('-8110102381441109808', ({}));
(arg1) = 1;
codealchemist_log_type_post('-8110102381441109808', ({v0 : ((typeof arg1) != ('undefined')) ? (arg1) : (undefined)}));
codealchemist_log_type_pre('5404934103464501484', ({}));
(arg2) = 2;
codealchemist_log_type_post('5404934103464501484', ({v0 : ((typeof arg2) != ('undefined')) ? (arg2) : (undefined)}));
codealchemist_log_type_pre('-2883320476094799205', ({}));
(arg3) = 3;
codealchemist_log_type_post('-2883320476094799205', ({v0 : ((typeof arg3) != ('undefined')) ? (arg3) : (undefined)}));
codealchemist_log_type_pre('-1828068506636376728', ({}));
(arg4) = 4;
codealchemist_log_type_post('-1828068506636376728', ({v0 : ((typeof arg4) != ('undefined')) ? (arg4) : (undefined)}));
codealchemist_log_type_pre('-8958143691143140468', ({}));
(arg5) = 5;
codealchemist_log_type_post('-8958143691143140468', ({v0 : ((typeof arg5) != ('undefined')) ? (arg5) : (undefined)}));
codealchemist_log_type_pre('4592367980711847821', ({}));
(arg6) = 6;
codealchemist_log_type_post('4592367980711847821', ({v0 : ((typeof arg6) != ('undefined')) ? (arg6) : (undefined)}));
codealchemist_log_type_pre('999766926368342872', ({}));
(arg7) = 7;
codealchemist_log_type_post('999766926368342872', ({v0 : ((typeof arg7) != ('undefined')) ? (arg7) : (undefined)}));
codealchemist_log_type_pre('3037630349319744861', ({}));
(arg8) = 8;
codealchemist_log_type_post('3037630349319744861', ({v0 : ((typeof arg8) != ('undefined')) ? (arg8) : (undefined)}));
codealchemist_log_type_pre('-1888767216138841780', ({}));
(arg9) = 9;
codealchemist_log_type_post('-1888767216138841780', ({v0 : ((typeof arg9) != ('undefined')) ? (arg9) : (undefined)}));
codealchemist_log_type_pre('-4491272071132663972', ({}));
(arg10) = 10;
codealchemist_log_type_post('-4491272071132663972', ({v0 : ((typeof arg10) != ('undefined')) ? (arg10) : (undefined)}));
codealchemist_log_type_pre('-5980481716977089109', ({}));
(arg11) = 11;
codealchemist_log_type_post('-5980481716977089109', ({v0 : ((typeof arg11) != ('undefined')) ? (arg11) : (undefined)}));
codealchemist_log_type_pre('-581725748990702988', ({}));
(arg12) = 12;
codealchemist_log_type_post('-581725748990702988', ({v0 : ((typeof arg12) != ('undefined')) ? (arg12) : (undefined)}));
codealchemist_log_type_pre('-6240201512674301989', ({}));
(arg13) = 13;
codealchemist_log_type_post('-6240201512674301989', ({v0 : ((typeof arg13) != ('undefined')) ? (arg13) : (undefined)}));
codealchemist_log_type_pre('6566163573852557583', ({}));
(arg14) = 14;
codealchemist_log_type_post('6566163573852557583', ({v0 : ((typeof arg14) != ('undefined')) ? (arg14) : (undefined)}));
codealchemist_log_type_pre('8300251153796227826', ({}));
(arg15) = 15;
codealchemist_log_type_post('8300251153796227826', ({v0 : ((typeof arg15) != ('undefined')) ? (arg15) : (undefined)}));
codealchemist_log_type_pre('-2112703699522817800', ({}));
(arg16) = 16;
codealchemist_log_type_post('-2112703699522817800', ({v0 : ((typeof arg16) != ('undefined')) ? (arg16) : (undefined)}));
codealchemist_log_type_pre('3881837863914344664', ({}));
(arg17) = 17;
codealchemist_log_type_post('3881837863914344664', ({v0 : ((typeof arg17) != ('undefined')) ? (arg17) : (undefined)}));
codealchemist_log_type_pre('2535268652054925286', ({}));
(arg18) = 18;
codealchemist_log_type_post('2535268652054925286', ({v0 : ((typeof arg18) != ('undefined')) ? (arg18) : (undefined)}));
codealchemist_log_type_pre('3835286726772109975', ({}));
(arg19) = 19;
codealchemist_log_type_post('3835286726772109975', ({v0 : ((typeof arg19) != ('undefined')) ? (arg19) : (undefined)}));
codealchemist_log_type_pre('137745887715269278', ({}));
(arg20) = 20;
codealchemist_log_type_post('137745887715269278', ({v0 : ((typeof arg20) != ('undefined')) ? (arg20) : (undefined)}));
}
codealchemist_log_type_post('-356543566816654177', ({}));
})();
codealchemist_log_type_post('2283383799177146975', ({}));
