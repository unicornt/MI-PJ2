load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
load("base_search.js");
codealchemist_log_type_pre('-3393295735527066208', ({v0 : ((typeof createBenchmarkSuite) != ('undefined')) ? (createBenchmarkSuite) : (undefined)}));
createBenchmarkSuite("Search");
codealchemist_log_type_post('-3393295735527066208', ({v0 : ((typeof createBenchmarkSuite) != ('undefined')) ? (createBenchmarkSuite) : (undefined)}));
