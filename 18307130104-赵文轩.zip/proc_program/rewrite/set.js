load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('-3018458187486552237', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
var SetSmiBenchmark = new BenchmarkSuite('Set-Smi', [], []);
codealchemist_log_type_post('-3018458187486552237', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v0 : ((typeof SetSmiBenchmark) != ('undefined')) ? (SetSmiBenchmark) : (undefined)}));
codealchemist_log_type_pre('4111232654423277517', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
var SetStringBenchmark = new BenchmarkSuite('Set-String', [], []);
codealchemist_log_type_post('4111232654423277517', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v0 : ((typeof SetStringBenchmark) != ('undefined')) ? (SetStringBenchmark) : (undefined)}));
codealchemist_log_type_pre('7755166479456708514', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
var SetObjectBenchmark = new BenchmarkSuite('Set-Object', [], []);
codealchemist_log_type_post('7755166479456708514', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v0 : ((typeof SetObjectBenchmark) != ('undefined')) ? (SetObjectBenchmark) : (undefined)}));
codealchemist_log_type_pre('-1463749188655001418', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
var SetDoubleBenchmark = new BenchmarkSuite('Set-Double', [], []);
codealchemist_log_type_post('-1463749188655001418', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v0 : ((typeof SetDoubleBenchmark) != ('undefined')) ? (SetDoubleBenchmark) : (undefined)}));
codealchemist_log_type_pre('3156059258148420366', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
var SetIterationBenchmark = new BenchmarkSuite('Set-Iteration', [], []);
codealchemist_log_type_post('3156059258148420366', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v0 : ((typeof SetIterationBenchmark) != ('undefined')) ? (SetIterationBenchmark) : (undefined)}));
codealchemist_log_type_pre('-2440855314020969244', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
var SetIterationBenchmark = new BenchmarkSuite('Set-Iterator', [], []);
codealchemist_log_type_post('-2440855314020969244', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v0 : ((typeof SetIterationBenchmark) != ('undefined')) ? (SetIterationBenchmark) : (undefined)}));
codealchemist_log_type_pre('-3939050663172274749', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
var SetConstructorBenchmark = new BenchmarkSuite('Set-Constructor', [], []);
codealchemist_log_type_post('-3939050663172274749', ({v1 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v0 : ((typeof SetConstructorBenchmark) != ('undefined')) ? (SetConstructorBenchmark) : (undefined)}));
codealchemist_log_type_pre('-7265530382583183660', ({}));
var set;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1413182180352947639', ({v1 : ((typeof SetupSmiKeys) != ('undefined')) ? (SetupSmiKeys) : (undefined)}));
function SetSetupSmiBase(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetupSmiKeys) != ('undefined')) ? (SetupSmiKeys) : (undefined)}));
SetupSmiKeys();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetupSmiKeys) != ('undefined')) ? (SetupSmiKeys) : (undefined)}));
codealchemist_log_type_pre('-857128021771431206', ({}));
(set) = new Set();
codealchemist_log_type_post('-857128021771431206', ({v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-1413182180352947639', ({}));
codealchemist_log_type_pre('-3031649570852991105', ({v2 : ((typeof SetAddSmi) != ('undefined')) ? (SetAddSmi) : (undefined), v1 : ((typeof SetSetupSmiBase) != ('undefined')) ? (SetSetupSmiBase) : (undefined)}));
function SetSetupSmi(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetSetupSmiBase) != ('undefined')) ? (SetSetupSmiBase) : (undefined)}));
SetSetupSmiBase();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetSetupSmiBase) != ('undefined')) ? (SetSetupSmiBase) : (undefined)}));
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetAddSmi) != ('undefined')) ? (SetAddSmi) : (undefined)}));
SetAddSmi();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetAddSmi) != ('undefined')) ? (SetAddSmi) : (undefined)}));
}
codealchemist_log_type_post('-3031649570852991105', ({}));
codealchemist_log_type_pre('-1413182180352947639', ({v1 : ((typeof SetupStringKeys) != ('undefined')) ? (SetupStringKeys) : (undefined)}));
function SetSetupStringBase(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetupStringKeys) != ('undefined')) ? (SetupStringKeys) : (undefined)}));
SetupStringKeys();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetupStringKeys) != ('undefined')) ? (SetupStringKeys) : (undefined)}));
codealchemist_log_type_pre('-857128021771431206', ({}));
(set) = new Set();
codealchemist_log_type_post('-857128021771431206', ({v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-1413182180352947639', ({}));
codealchemist_log_type_pre('-3031649570852991105', ({v2 : ((typeof SetAddString) != ('undefined')) ? (SetAddString) : (undefined), v1 : ((typeof SetSetupStringBase) != ('undefined')) ? (SetSetupStringBase) : (undefined)}));
function SetSetupString(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetSetupStringBase) != ('undefined')) ? (SetSetupStringBase) : (undefined)}));
SetSetupStringBase();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetSetupStringBase) != ('undefined')) ? (SetSetupStringBase) : (undefined)}));
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetAddString) != ('undefined')) ? (SetAddString) : (undefined)}));
SetAddString();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetAddString) != ('undefined')) ? (SetAddString) : (undefined)}));
}
codealchemist_log_type_post('-3031649570852991105', ({}));
codealchemist_log_type_pre('-1413182180352947639', ({v1 : ((typeof SetupObjectKeys) != ('undefined')) ? (SetupObjectKeys) : (undefined)}));
function SetSetupObjectBase(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetupObjectKeys) != ('undefined')) ? (SetupObjectKeys) : (undefined)}));
SetupObjectKeys();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetupObjectKeys) != ('undefined')) ? (SetupObjectKeys) : (undefined)}));
codealchemist_log_type_pre('-857128021771431206', ({}));
(set) = new Set();
codealchemist_log_type_post('-857128021771431206', ({v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-1413182180352947639', ({}));
codealchemist_log_type_pre('-3031649570852991105', ({v2 : ((typeof SetAddObject) != ('undefined')) ? (SetAddObject) : (undefined), v1 : ((typeof SetSetupObjectBase) != ('undefined')) ? (SetSetupObjectBase) : (undefined)}));
function SetSetupObject(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetSetupObjectBase) != ('undefined')) ? (SetSetupObjectBase) : (undefined)}));
SetSetupObjectBase();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetSetupObjectBase) != ('undefined')) ? (SetSetupObjectBase) : (undefined)}));
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetAddObject) != ('undefined')) ? (SetAddObject) : (undefined)}));
SetAddObject();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetAddObject) != ('undefined')) ? (SetAddObject) : (undefined)}));
}
codealchemist_log_type_post('-3031649570852991105', ({}));
codealchemist_log_type_pre('-1413182180352947639', ({v1 : ((typeof SetupDoubleKeys) != ('undefined')) ? (SetupDoubleKeys) : (undefined)}));
function SetSetupDoubleBase(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetupDoubleKeys) != ('undefined')) ? (SetupDoubleKeys) : (undefined)}));
SetupDoubleKeys();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetupDoubleKeys) != ('undefined')) ? (SetupDoubleKeys) : (undefined)}));
codealchemist_log_type_pre('-857128021771431206', ({}));
(set) = new Set();
codealchemist_log_type_post('-857128021771431206', ({v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-1413182180352947639', ({}));
codealchemist_log_type_pre('-3031649570852991105', ({v2 : ((typeof SetAddDouble) != ('undefined')) ? (SetAddDouble) : (undefined), v1 : ((typeof SetSetupDoubleBase) != ('undefined')) ? (SetSetupDoubleBase) : (undefined)}));
function SetSetupDouble(){
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetSetupDoubleBase) != ('undefined')) ? (SetSetupDoubleBase) : (undefined)}));
SetSetupDoubleBase();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetSetupDoubleBase) != ('undefined')) ? (SetSetupDoubleBase) : (undefined)}));
codealchemist_log_type_pre('4051885568687879871', ({v0 : ((typeof SetAddDouble) != ('undefined')) ? (SetAddDouble) : (undefined)}));
SetAddDouble();
codealchemist_log_type_post('4051885568687879871', ({v0 : ((typeof SetAddDouble) != ('undefined')) ? (SetAddDouble) : (undefined)}));
}
codealchemist_log_type_post('-3031649570852991105', ({}));
codealchemist_log_type_pre('-7723396004823776748', ({}));
function SetTearDown(){
codealchemist_log_type_pre('6697378765710824163', ({}));
(set) = null;
codealchemist_log_type_post('6697378765710824163', ({v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-7723396004823776748', ({}));
codealchemist_log_type_pre('6981440985847363288', ({v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined)}));
function SetConstructorSmi(){
codealchemist_log_type_pre('-1707035785284661422', ({v2 : ((typeof keys) != ('undefined')) ? (keys) : (undefined)}));
(set) = new Set(keys);
codealchemist_log_type_post('-1707035785284661422', ({v2 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('6981440985847363288', ({}));
codealchemist_log_type_pre('3990392461152675968', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetAddSmi(){
codealchemist_log_type_pre('5485094119321473635', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('-8992096072284959232', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1470530900886322832', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.add(keys[i], i);
codealchemist_log_type_post('-1470530900886322832', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('-8992096072284959232', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('5485094119321473635', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('3990392461152675968', ({}));
codealchemist_log_type_pre('-3686419166265436543', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetHasSmi(){
codealchemist_log_type_pre('-621433012088521822', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('-8857762378008280186', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-2316910496361811858', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
if(! set.has(keys[i])){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('-2316910496361811858', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('-8857762378008280186', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-621433012088521822', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('519929105421021164', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = N;(i) < ((2) * (N));i++){
codealchemist_log_type_pre('2604784878593788424', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('2065783575243209488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
if(set.has(keys[i])){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('2065783575243209488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('2604784878593788424', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('519929105421021164', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-3686419166265436543', ({}));
codealchemist_log_type_pre('7080795309524355395', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetDeleteSmi(){
codealchemist_log_type_pre('-1045222980481924519', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('2532352819362737821', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1608961698552069488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.delete(keys[i]);
codealchemist_log_type_post('-1608961698552069488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('2532352819362737821', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-1045222980481924519', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('7080795309524355395', ({}));
codealchemist_log_type_pre('6981440985847363288', ({v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined)}));
function SetConstructorString(){
codealchemist_log_type_pre('-1707035785284661422', ({v2 : ((typeof keys) != ('undefined')) ? (keys) : (undefined)}));
(set) = new Set(keys);
codealchemist_log_type_post('-1707035785284661422', ({v2 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('6981440985847363288', ({}));
codealchemist_log_type_pre('3990392461152675968', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetAddString(){
codealchemist_log_type_pre('5485094119321473635', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('-8992096072284959232', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1470530900886322832', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.add(keys[i], i);
codealchemist_log_type_post('-1470530900886322832', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('-8992096072284959232', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('5485094119321473635', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('3990392461152675968', ({}));
codealchemist_log_type_pre('-3686419166265436543', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetHasString(){
codealchemist_log_type_pre('-621433012088521822', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('-8857762378008280186', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-2316910496361811858', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
if(! set.has(keys[i])){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('-2316910496361811858', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('-8857762378008280186', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-621433012088521822', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('519929105421021164', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = N;(i) < ((2) * (N));i++){
codealchemist_log_type_pre('2604784878593788424', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('2065783575243209488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
if(set.has(keys[i])){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('2065783575243209488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('2604784878593788424', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('519929105421021164', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-3686419166265436543', ({}));
codealchemist_log_type_pre('7080795309524355395', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetDeleteString(){
codealchemist_log_type_pre('-1045222980481924519', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('2532352819362737821', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1608961698552069488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.delete(keys[i]);
codealchemist_log_type_post('-1608961698552069488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('2532352819362737821', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-1045222980481924519', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('7080795309524355395', ({}));
codealchemist_log_type_pre('6981440985847363288', ({v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined)}));
function SetConstructorObject(){
codealchemist_log_type_pre('-1707035785284661422', ({v2 : ((typeof keys) != ('undefined')) ? (keys) : (undefined)}));
(set) = new Set(keys);
codealchemist_log_type_post('-1707035785284661422', ({v2 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('6981440985847363288', ({}));
codealchemist_log_type_pre('3990392461152675968', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetAddObject(){
codealchemist_log_type_pre('5485094119321473635', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('-8992096072284959232', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1470530900886322832', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.add(keys[i], i);
codealchemist_log_type_post('-1470530900886322832', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('-8992096072284959232', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('5485094119321473635', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('3990392461152675968', ({}));
codealchemist_log_type_pre('-3686419166265436543', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetHasObject(){
codealchemist_log_type_pre('-621433012088521822', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('-8857762378008280186', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-2316910496361811858', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
if(! set.has(keys[i])){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('-2316910496361811858', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('-8857762378008280186', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-621433012088521822', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('519929105421021164', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = N;(i) < ((2) * (N));i++){
codealchemist_log_type_pre('2604784878593788424', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('2065783575243209488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
if(set.has(keys[i])){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('2065783575243209488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('2604784878593788424', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('519929105421021164', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-3686419166265436543', ({}));
codealchemist_log_type_pre('7080795309524355395', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetDeleteObject(){
codealchemist_log_type_pre('-1045222980481924519', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('2532352819362737821', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1608961698552069488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.delete(keys[i]);
codealchemist_log_type_post('-1608961698552069488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('2532352819362737821', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-1045222980481924519', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('7080795309524355395', ({}));
codealchemist_log_type_pre('6981440985847363288', ({v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined)}));
function SetConstructorDouble(){
codealchemist_log_type_pre('-1707035785284661422', ({v2 : ((typeof keys) != ('undefined')) ? (keys) : (undefined)}));
(set) = new Set(keys);
codealchemist_log_type_post('-1707035785284661422', ({v2 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('6981440985847363288', ({}));
codealchemist_log_type_pre('3990392461152675968', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetAddDouble(){
codealchemist_log_type_pre('5485094119321473635', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('-8992096072284959232', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1470530900886322832', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.add(keys[i], i);
codealchemist_log_type_post('-1470530900886322832', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('-8992096072284959232', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('5485094119321473635', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('3990392461152675968', ({}));
codealchemist_log_type_pre('-3686419166265436543', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetHasDouble(){
codealchemist_log_type_pre('-621433012088521822', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('-8857762378008280186', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-2316910496361811858', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
if(! set.has(keys[i])){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('-2316910496361811858', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('-8857762378008280186', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-621433012088521822', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('519929105421021164', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = N;(i) < ((2) * (N));i++){
codealchemist_log_type_pre('2604784878593788424', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('2065783575243209488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
if(set.has(keys[i])){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('2065783575243209488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('2604784878593788424', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('519929105421021164', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-3686419166265436543', ({}));
codealchemist_log_type_pre('7080795309524355395', ({v2 : ((typeof N) != ('undefined')) ? (N) : (undefined), v4 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetDeleteDouble(){
codealchemist_log_type_pre('-1045222980481924519', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(var i = 0;(i) < (N);i++){
codealchemist_log_type_pre('2532352819362737821', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_pre('-1608961698552069488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.delete(keys[i]);
codealchemist_log_type_post('-1608961698552069488', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
codealchemist_log_type_post('2532352819362737821', ({v2 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('-1045222980481924519', ({v1 : ((typeof N) != ('undefined')) ? (N) : (undefined), v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v3 : ((typeof keys) != ('undefined')) ? (keys) : (undefined), v2 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('7080795309524355395', ({}));
codealchemist_log_type_pre('4091898744494890406', ({v1 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetForEach(){
codealchemist_log_type_pre('-2198036984612939346', ({v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
set.forEach((function (v, k){
codealchemist_log_type_pre('431813762533847129', ({v1 : ((typeof k) != ('undefined')) ? (k) : (undefined), v0 : ((typeof v) != ('undefined')) ? (v) : (undefined)}));
if((v) !== (k)){
codealchemist_log_type_pre('5802199338371819523', ({}));
codealchemist_log_type_pre('3997529895621314748', ({}));
var temp_3997529895621314748 = new Error();
codealchemist_log_type_post('3997529895621314748', ({}));
throw temp_3997529895621314748;
codealchemist_log_type_post('5802199338371819523', ({}));
}
codealchemist_log_type_post('431813762533847129', ({v1 : ((typeof k) != ('undefined')) ? (k) : (undefined), v0 : ((typeof v) != ('undefined')) ? (v) : (undefined)}));
}));
codealchemist_log_type_post('-2198036984612939346', ({v0 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
}
codealchemist_log_type_post('4091898744494890406', ({}));
codealchemist_log_type_pre('-4924785578736360738', ({v3 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
function SetIterator(){
codealchemist_log_type_pre('8887107388399914408', ({}));
var result = 0;
codealchemist_log_type_post('8887107388399914408', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
codealchemist_log_type_pre('1956498878179229418', ({v2 : ((typeof result) != ('undefined')) ? (result) : (undefined), v1 : ((typeof set) != ('undefined')) ? (set) : (undefined)}));
for(const v of set){
codealchemist_log_type_pre('383496466578906810', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined), v1 : ((typeof v) != ('undefined')) ? (v) : (undefined)}));
(result) += v;
codealchemist_log_type_post('383496466578906810', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined), v1 : ((typeof v) != ('undefined')) ? (v) : (undefined)}));
}
codealchemist_log_type_post('1956498878179229418', ({v2 : ((typeof result) != ('undefined')) ? (result) : (undefined), v1 : ((typeof set) != ('undefined')) ? (set) : (undefined), v0 : ((typeof v) != ('undefined')) ? (v) : (undefined)}));
codealchemist_log_type_pre('-3444589576563574513', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
var temp_3444589576563574513 = result;
codealchemist_log_type_post('-3444589576563574513', ({v0 : ((typeof result) != ('undefined')) ? (result) : (undefined)}));
return temp_3444589576563574513;
}
codealchemist_log_type_post('-4924785578736360738', ({}));
