load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
load("base_flags.js");
codealchemist_log_type_pre('-5513191095768849268', ({v0 : ((typeof createSlowBenchmarkSuite) != ('undefined')) ? (createSlowBenchmarkSuite) : (undefined)}));
createSlowBenchmarkSuite("Flags");
codealchemist_log_type_post('-5513191095768849268', ({v0 : ((typeof createSlowBenchmarkSuite) != ('undefined')) ? (createSlowBenchmarkSuite) : (undefined)}));
