load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
load("base_replace.js");
codealchemist_log_type_pre('-3592484481494632772', ({v0 : ((typeof createSlowBenchmarkSuite) != ('undefined')) ? (createSlowBenchmarkSuite) : (undefined)}));
createSlowBenchmarkSuite("Replace");
codealchemist_log_type_post('-3592484481494632772', ({v0 : ((typeof createSlowBenchmarkSuite) != ('undefined')) ? (createSlowBenchmarkSuite) : (undefined)}));
