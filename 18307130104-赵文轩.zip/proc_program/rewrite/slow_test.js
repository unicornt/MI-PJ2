load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load("base.js");
load("base_test.js");
codealchemist_log_type_pre('1830385553247015709', ({v0 : ((typeof createSlowBenchmarkSuite) != ('undefined')) ? (createSlowBenchmarkSuite) : (undefined)}));
createSlowBenchmarkSuite("Test");
codealchemist_log_type_post('1830385553247015709', ({v0 : ((typeof createSlowBenchmarkSuite) != ('undefined')) ? (createSlowBenchmarkSuite) : (undefined)}));
