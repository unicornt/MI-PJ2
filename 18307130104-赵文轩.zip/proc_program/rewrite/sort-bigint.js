load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load('sort.js');
codealchemist_log_type_pre('-779858027237526122', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v1 : ((typeof CreateBenchmarks) != ('undefined')) ? (CreateBenchmarks) : (undefined), v2 : ((typeof typedArrayBigIntConstructors) != ('undefined')) ? (typedArrayBigIntConstructors) : (undefined)}));
new BenchmarkSuite('SortBigIntTypes', [], CreateBenchmarks(typedArrayBigIntConstructors));
codealchemist_log_type_post('-779858027237526122', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v1 : ((typeof CreateBenchmarks) != ('undefined')) ? (CreateBenchmarks) : (undefined), v2 : ((typeof typedArrayBigIntConstructors) != ('undefined')) ? (typedArrayBigIntConstructors) : (undefined)}));
