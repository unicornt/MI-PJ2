load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
load('sort.js');
codealchemist_log_type_pre('-7976793842341657706', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v1 : ((typeof CreateBenchmarks) != ('undefined')) ? (CreateBenchmarks) : (undefined), v2 : ((typeof typedArrayBigIntConstructors) != ('undefined')) ? (typedArrayBigIntConstructors) : (undefined)}));
new BenchmarkSuite('SortCustomCompareFnBigIntTypes', [], CreateBenchmarks(typedArrayBigIntConstructors, []));
codealchemist_log_type_post('-7976793842341657706', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined), v1 : ((typeof CreateBenchmarks) != ('undefined')) ? (CreateBenchmarks) : (undefined), v2 : ((typeof typedArrayBigIntConstructors) != ('undefined')) ? (typedArrayBigIntConstructors) : (undefined)}));
