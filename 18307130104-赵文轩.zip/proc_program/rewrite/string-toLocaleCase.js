load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('-9070894213577357247', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('StringToLocaleUpperCaseTR', [], []);
codealchemist_log_type_post('-9070894213577357247', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('-5444581251092267937', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('StringToLocaleLowerCaseTR', [], []);
codealchemist_log_type_post('-5444581251092267937', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('1428043747326770448', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('StringToLocaleUpperCase', [], []);
codealchemist_log_type_post('1428043747326770448', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('2882395250945283791', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
new BenchmarkSuite('StringToLocaleLowerCase', [], []);
codealchemist_log_type_post('2882395250945283791', ({v0 : ((typeof BenchmarkSuite) != ('undefined')) ? (BenchmarkSuite) : (undefined)}));
codealchemist_log_type_pre('7148446420803146493', ({}));
var shortString = "Îñţérñåţîöñåļîžåţîöñ Ļöçåļîžåţîöñ החןןם שםוןמ Γρεεκ ισ φθν 一二三";
codealchemist_log_type_post('7148446420803146493', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
codealchemist_log_type_pre('-6516984973203245591', ({v1 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
function StringToLocaleUpperCase(){
codealchemist_log_type_pre('-1524740092210098090', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
var temp_1524740092210098090 = shortString.toLocaleUpperCase();
codealchemist_log_type_post('-1524740092210098090', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
return temp_1524740092210098090;
}
codealchemist_log_type_post('-6516984973203245591', ({}));
codealchemist_log_type_pre('5675394329429793921', ({v1 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
function StringToLocaleLowerCase(){
codealchemist_log_type_pre('5378808568889053835', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
var temp_5378808568889053835 = shortString.toLocaleLowerCase();
codealchemist_log_type_post('5378808568889053835', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
return temp_5378808568889053835;
}
codealchemist_log_type_post('5675394329429793921', ({}));
codealchemist_log_type_pre('-4684090184305540871', ({v1 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
function StringToLocaleUpperCaseTR(){
codealchemist_log_type_pre('-939748287265623188', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
var temp_939748287265623188 = shortString.toLocaleUpperCase([]);
codealchemist_log_type_post('-939748287265623188', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
return temp_939748287265623188;
}
codealchemist_log_type_post('-4684090184305540871', ({}));
codealchemist_log_type_pre('8924590561947445951', ({v1 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
function StringToLocaleLowerCaseTR(){
codealchemist_log_type_pre('-3744965746262213403', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
var temp_3744965746262213403 = shortString.toLocaleLowerCase([]);
codealchemist_log_type_post('-3744965746262213403', ({v0 : ((typeof shortString) != ('undefined')) ? (shortString) : (undefined)}));
return temp_3744965746262213403;
}
codealchemist_log_type_post('8924590561947445951', ({}));
