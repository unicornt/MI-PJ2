load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('-2872901346425574012', ({}));
function NumberToHexString(){
codealchemist_log_type_pre('-1849372821972001073', ({}));
Number(0).toString(16);
codealchemist_log_type_post('-1849372821972001073', ({}));
codealchemist_log_type_pre('-5953440705881438401', ({}));
Number(- 12).toString(16);
codealchemist_log_type_post('-5953440705881438401', ({}));
codealchemist_log_type_pre('3496063115533863002', ({}));
Number(13).toString(16);
codealchemist_log_type_post('3496063115533863002', ({}));
codealchemist_log_type_pre('-3613153912412737442', ({}));
Number(123456789).toString(16);
codealchemist_log_type_post('-3613153912412737442', ({}));
codealchemist_log_type_pre('-8685331794153126811', ({}));
Number(1234567.89).toString(16);
codealchemist_log_type_post('-8685331794153126811', ({}));
codealchemist_log_type_pre('1299381061526644255', ({}));
Number(- 123456789).toString(16);
codealchemist_log_type_post('1299381061526644255', ({}));
codealchemist_log_type_pre('-5192011315164183235', ({}));
Number(- 1234567.89).toString(16);
codealchemist_log_type_post('-5192011315164183235', ({}));
}
codealchemist_log_type_post('-2872901346425574012', ({}));
codealchemist_log_type_pre('-4606827435277872184', ({v1 : ((typeof NumberToHexString) != ('undefined')) ? (NumberToHexString) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('toHexString', 100000, NumberToHexString, (()=>{
}));
codealchemist_log_type_post('-4606827435277872184', ({v1 : ((typeof NumberToHexString) != ('undefined')) ? (NumberToHexString) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
