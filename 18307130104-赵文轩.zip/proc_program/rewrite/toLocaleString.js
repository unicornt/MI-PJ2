load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('4120369159100217599', ({}));
function NumberToLocaleString(){
codealchemist_log_type_pre('-267139135335750748', ({}));
Number(0).toLocaleString();
codealchemist_log_type_post('-267139135335750748', ({}));
codealchemist_log_type_pre('353204909799439347', ({}));
Number(- 12).toLocaleString();
codealchemist_log_type_post('353204909799439347', ({}));
codealchemist_log_type_pre('-7857500975588651472', ({}));
Number(13).toLocaleString();
codealchemist_log_type_post('-7857500975588651472', ({}));
codealchemist_log_type_pre('-8309055136234796767', ({}));
Number(123456789).toLocaleString();
codealchemist_log_type_post('-8309055136234796767', ({}));
codealchemist_log_type_pre('-2523533006545554311', ({}));
Number(1234567.89).toLocaleString();
codealchemist_log_type_post('-2523533006545554311', ({}));
codealchemist_log_type_pre('2710404189244847691', ({}));
Number(- 123456789).toLocaleString();
codealchemist_log_type_post('2710404189244847691', ({}));
codealchemist_log_type_pre('-511601981522875874', ({}));
Number(- 1234567.89).toLocaleString();
codealchemist_log_type_post('-511601981522875874', ({}));
}
codealchemist_log_type_post('4120369159100217599', ({}));
codealchemist_log_type_pre('-2415937411294657656', ({v1 : ((typeof NumberToLocaleString) != ('undefined')) ? (NumberToLocaleString) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('toLocaleString', 100000, NumberToLocaleString, (()=>{
}));
codealchemist_log_type_post('-2415937411294657656', ({v1 : ((typeof NumberToLocaleString) != ('undefined')) ? (NumberToLocaleString) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
