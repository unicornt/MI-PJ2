load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('7838083884550891431', ({}));
const A = [];
codealchemist_log_type_post('7838083884550891431', ({v0 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
codealchemist_log_type_pre('-3561121738587151250', ({v2 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
function NumberConstructor(){
codealchemist_log_type_pre('-2006452686847863955', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(Number(A[0]));
codealchemist_log_type_post('-2006452686847863955', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
codealchemist_log_type_pre('-3521763115523972531', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(Number(A[1]));
codealchemist_log_type_post('-3521763115523972531', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
codealchemist_log_type_pre('-5165569834700593398', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(Number(A[2]));
codealchemist_log_type_post('-5165569834700593398', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
}
codealchemist_log_type_post('-3561121738587151250', ({}));
codealchemist_log_type_pre('7753448678858075694', ({v1 : ((typeof NumberConstructor) != ('undefined')) ? (NumberConstructor) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('Constructor', 1000, NumberConstructor, (()=>{
}));
codealchemist_log_type_post('7753448678858075694', ({v1 : ((typeof NumberConstructor) != ('undefined')) ? (NumberConstructor) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('6783721316950409184', ({v2 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
function NumberPlus(){
codealchemist_log_type_pre('-523577481561668561', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(+ A[0]);
codealchemist_log_type_post('-523577481561668561', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
codealchemist_log_type_pre('1410508757870743536', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(+ A[1]);
codealchemist_log_type_post('1410508757870743536', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
codealchemist_log_type_pre('-1547693942799367189', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(+ A[2]);
codealchemist_log_type_post('-1547693942799367189', ({v1 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
}
codealchemist_log_type_post('6783721316950409184', ({}));
codealchemist_log_type_pre('-5983760290026135098', ({v1 : ((typeof NumberPlus) != ('undefined')) ? (NumberPlus) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('UnaryPlus', 1000, NumberPlus, (()=>{
}));
codealchemist_log_type_post('-5983760290026135098', ({v1 : ((typeof NumberPlus) != ('undefined')) ? (NumberPlus) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
codealchemist_log_type_pre('5051369079559922802', ({v3 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
function NumberParseFloat(){
codealchemist_log_type_pre('8519055795894051619', ({v2 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(parseFloat(A[0]));
codealchemist_log_type_post('8519055795894051619', ({v2 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
codealchemist_log_type_pre('4058908260267890472', ({v2 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(parseFloat(A[1]));
codealchemist_log_type_post('4058908260267890472', ({v2 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
codealchemist_log_type_pre('7032308739168766468', ({v2 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
Number.isNaN(parseFloat(A[2]));
codealchemist_log_type_post('7032308739168766468', ({v2 : ((typeof A) != ('undefined')) ? (A) : (undefined)}));
}
codealchemist_log_type_post('5051369079559922802', ({}));
codealchemist_log_type_pre('-7747246722628546894', ({v1 : ((typeof NumberParseFloat) != ('undefined')) ? (NumberParseFloat) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('ParseFloat', 1000, NumberParseFloat, (()=>{
}));
codealchemist_log_type_post('-7747246722628546894', ({v1 : ((typeof NumberParseFloat) != ('undefined')) ? (NumberParseFloat) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
