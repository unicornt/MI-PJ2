load('/mnt/c/Users/unicornt/Desktop/0/pj/CodeAlchemist/bin/jsLib/V8.js');
codealchemist_log_type_pre('99406555997079564', ({}));
function NumberToString(){
codealchemist_log_type_pre('-7265530382583183660', ({}));
var ret;
codealchemist_log_type_post('-7265530382583183660', ({v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
codealchemist_log_type_pre('5851863980183266741', ({}));
var num = 10240;
codealchemist_log_type_post('5851863980183266741', ({v0 : ((typeof num) != ('undefined')) ? (num) : (undefined)}));
codealchemist_log_type_pre('-2256249072298133429', ({}));
var obj = ({});
codealchemist_log_type_post('-2256249072298133429', ({v0 : ((typeof obj) != ('undefined')) ? (obj) : (undefined)}));
codealchemist_log_type_pre('-1065073364437404735', ({v1 : ((typeof num) != ('undefined')) ? (num) : (undefined), v3 : ((typeof obj) != ('undefined')) ? (obj) : (undefined)}));
for(var i = 0;(i) < (num);i++){
codealchemist_log_type_pre('6995184352873622848', ({v2 : ((typeof num) != ('undefined')) ? (num) : (undefined), v1 : ((typeof obj) != ('undefined')) ? (obj) : (undefined)}));
codealchemist_log_type_pre('-6850934854343753099', ({v2 : ((typeof num) != ('undefined')) ? (num) : (undefined), v1 : ((typeof obj) != ('undefined')) ? (obj) : (undefined)}));
(ret) = obj[("test") + (num)];
codealchemist_log_type_post('-6850934854343753099', ({v2 : ((typeof num) != ('undefined')) ? (num) : (undefined), v1 : ((typeof obj) != ('undefined')) ? (obj) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
codealchemist_log_type_post('6995184352873622848', ({v2 : ((typeof num) != ('undefined')) ? (num) : (undefined), v1 : ((typeof obj) != ('undefined')) ? (obj) : (undefined), v0 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
}
codealchemist_log_type_post('-1065073364437404735', ({v0 : ((typeof i) != ('undefined')) ? (i) : (undefined), v1 : ((typeof num) != ('undefined')) ? (num) : (undefined), v3 : ((typeof obj) != ('undefined')) ? (obj) : (undefined), v2 : ((typeof ret) != ('undefined')) ? (ret) : (undefined)}));
}
codealchemist_log_type_post('99406555997079564', ({}));
codealchemist_log_type_pre('2822117000553288454', ({v1 : ((typeof NumberToString) != ('undefined')) ? (NumberToString) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
createSuite('NumberToString', 1000, NumberToString);
codealchemist_log_type_post('2822117000553288454', ({v1 : ((typeof NumberToString) != ('undefined')) ? (NumberToString) : (undefined), v0 : ((typeof createSuite) != ('undefined')) ? (createSuite) : (undefined)}));
