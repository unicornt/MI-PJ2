[
{ "hval": 7838083884550891431,
  "pre": {},
  "post": {"v0":"Array"}}
,
{ "hval": -7265530382583183660,
  "pre": {},
  "post": {"v0":"undefined"}}
,
{ "hval": 4318727432189937553,
  "pre": {"v1":"undefined","v2":"undefined"},
  "post": {}}
,
{ "hval": -6354574074603030189,
  "pre": {"v3":"undefined"},
  "post": {}}
,
{ "hval": -2163726698169737211,
  "pre": {"v3":"undefined"},
  "post": {}}
,
{ "hval": -2873575392672305138,
  "pre": {},
  "post": {"v0":"Array"}}
]