[
{ "hval": -3490613269553461262,
  "pre": {},
  "post": {"v0":"number"}}
,
{ "hval": 1031821779699913509,
  "pre": {},
  "post": {"v0":"number"}}
,
{ "hval": -7265530382583183660,
  "pre": {},
  "post": {"v0":"undefined"}}
,
{ "hval": -1400442680196102186,
  "pre": {"v2":"undefined"},
  "post": {}}
,
{ "hval": 4786530646626315440,
  "pre": {"v2":"number"},
  "post": {"v2":"number"}}
,
{ "hval": 1361141975713418877,
  "pre": {"v2":"number","v4":"function","v3":"function"},
  "post": {"v2":"number"}}
,
{ "hval": -5064727983552712127,
  "pre": {"v2":"number"},
  "post": {"v2":"number"}}
,
{ "hval": -7369449796771026490,
  "pre": {"v2":"number"},
  "post": {"v2":"number"}}
,
{ "hval": -7960456019717042195,
  "pre": {"v2":"number"},
  "post": {"v2":"number"}}
,
{ "hval": 1361141975713418877,
  "pre": {"v2":"number","v3":"function","v4":"function"},
  "post": {"v2":"number"}}
]