[
{ "hval": -228623553587885779,
  "pre": {},
  "post": {}}
,
{ "hval": -612646236789990164,
  "pre": {"v2":"function"},
  "post": {}}
,
{ "hval": -6552356829411029732,
  "pre": {},
  "post": {}}
,
{ "hval": -9198048984285996910,
  "pre": {},
  "post": {"v0":"object"}}
,
{ "hval": -2699773896895153586,
  "pre": {"v1":"object"},
  "post": {"v1":"object"}}
,
{ "hval": -5624505709923688540,
  "pre": {"v0":"object","v1":"function"},
  "post": {"v0":"object","v1":"function"}}
,
{ "hval": 3111538943136427222,
  "pre": {"v0":"object"},
  "post": {"v0":"object"}}
,
{ "hval": 4854959356697947957,
  "pre": {"v0":"object"},
  "post": {"v0":"object"}}
,
{ "hval": -3444589576563574513,
  "pre": {"v0":"object"},
  "post": {"v0":"object"}}
,
{ "hval": 8699103116531770005,
  "pre": {"v1":"object","v2":"string"},
  "post": {"v1":"object","v2":"string","v0":"object"}}
,
{ "hval": 2655849324972088741,
  "pre": {"v0":"object","v1":"string","v3":"object"},
  "post": {"v0":"object","v1":"string","v3":"object"}}
,
{ "hval": -9112689506574544490,
  "pre": {"v1":"object","v2":"string"},
  "post": {"v1":"object","v2":"string","v0":"object"}}
,
{ "hval": 8699103116531770005,
  "pre": {"v1":"object","v2":"string"},
  "post": {"v1":"object","v2":"string","v0":"Array"}}
,
{ "hval": 2655849324972088741,
  "pre": {"v0":"object","v1":"string","v3":"Array"},
  "post": {"v0":"object","v1":"string","v3":"Array"}}
,
{ "hval": -9112689506574544490,
  "pre": {"v1":"object","v2":"string"},
  "post": {"v1":"object","v2":"string","v0":"Array"}}
,
{ "hval": 2262051809191092222,
  "pre": {"v1":"object"},
  "post": {"v1":"object","v0":"string","v2":"object"}}
,
{ "hval": -2540609435935787007,
  "pre": {"v1":"function","v3":"function","v2":"object"},
  "post": {"v0":"object","v1":"function","v3":"function","v2":"object"}}
,
{ "hval": 4756555894591918916,
  "pre": {},
  "post": {"v0":"object"}}
,
{ "hval": -9058068576284233954,
  "pre": {"v3":"undefined","v2":"undefined"},
  "post": {"v0":"function"}}
,
{ "hval": -2873575392672305138,
  "pre": {},
  "post": {"v0":"Array"}}
,
{ "hval": 8699103116531770005,
  "pre": {"v1":"object","v2":"string"},
  "post": {"v1":"object","v2":"string","v0":"null"}}
,
{ "hval": -5024015488346407256,
  "pre": {"v2":"string","v1":"string"},
  "post": {"v0":"string","v2":"string","v1":"string"}}
]