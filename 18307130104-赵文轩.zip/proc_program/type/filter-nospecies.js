[
{ "hval": -1570063083217209043,
  "pre": {},
  "post": {"v0":"number"}}
,
{ "hval": -964963668777278771,
  "pre": {},
  "post": {"v0":"undefined"}}
,
{ "hval": 114666830616829277,
  "pre": {"v4":"number"},
  "post": {}}
,
{ "hval": -2033073565127590618,
  "pre": {"v4":"number","v2":"undefined","v1":"undefined"},
  "post": {}}
,
{ "hval": -2637574887219363701,
  "pre": {"v1":"function","v3":"undefined"},
  "post": {}}
]