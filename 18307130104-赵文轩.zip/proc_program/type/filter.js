[
{ "hval": -4733923792901426601,
  "pre": {"v4":"undefined","v7":"undefined"},
  "post": {}}
,
{ "hval": -2918867811197771430,
  "pre": {"v2":"function","v4":"undefined"},
  "post": {}}
,
{ "hval": 8675098603006748889,
  "pre": {"v3":"undefined"},
  "post": {}}
,
{ "hval": -4144375167697826940,
  "pre": {"v1":"function"},
  "post": {"v1":"function"}}
,
{ "hval": -3987458632548678936,
  "pre": {"v1":"function"},
  "post": {}}
,
{ "hval": -669827548547540183,
  "pre": {},
  "post": {}}
,
{ "hval": 8800362661971780811,
  "pre": {"v2":"undefined","v3":"undefined","v4":"function"},
  "post": {}}
]