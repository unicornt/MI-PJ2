[
{ "hval": -2558491268632415244,
  "pre": {"v3":"undefined"},
  "post": {}}
,
{ "hval": -4144375167697826940,
  "pre": {"v1":"function"},
  "post": {"v1":"function"}}
,
{ "hval": 1335033636361262848,
  "pre": {"v1":"function","v2":"undefined"},
  "post": {}}
,
{ "hval": -669827548547540183,
  "pre": {},
  "post": {}}
,
{ "hval": -2387223267202091087,
  "pre": {"v2":"undefined","v3":"undefined","v4":"function"},
  "post": {}}
,
{ "hval": 6748061896526637521,
  "pre": {"v3":"undefined","v5":"undefined"},
  "post": {}}
,
{ "hval": -2918867811197771430,
  "pre": {"v2":"function","v4":"undefined"},
  "post": {}}
]