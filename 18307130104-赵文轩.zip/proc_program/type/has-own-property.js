[
{ "hval": 3256914607123296687,
  "pre": {"v4":"undefined"},
  "post": {}}
,
{ "hval": 6848302637669060528,
  "pre": {"v1":"function"},
  "post": {}}
,
{ "hval": -993708076935335840,
  "pre": {"v1":"function"},
  "post": {}}
]