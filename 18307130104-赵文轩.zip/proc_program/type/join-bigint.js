[
{ "hval": -7265530382583183660,
  "pre": {},
  "post": {"v0":"undefined"}}
,
{ "hval": -5934158437519036897,
  "pre": {},
  "post": {"v0":"number"}}
]