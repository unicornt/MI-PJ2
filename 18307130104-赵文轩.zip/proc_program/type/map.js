[
{ "hval": 2149432426334242504,
  "pre": {"v3":"undefined","v6":"undefined"},
  "post": {}}
,
{ "hval": -2918867811197771430,
  "pre": {"v2":"function","v4":"undefined"},
  "post": {}}
,
{ "hval": 1884262620268515837,
  "pre": {"v3":"undefined"},
  "post": {}}
,
{ "hval": -4144375167697826940,
  "pre": {"v1":"function"},
  "post": {"v1":"function"}}
,
{ "hval": -3987458632548678936,
  "pre": {"v1":"function"},
  "post": {}}
,
{ "hval": -669827548547540183,
  "pre": {},
  "post": {}}
,
{ "hval": 3183850921393879164,
  "pre": {"v2":"undefined","v3":"undefined","v4":"function"},
  "post": {}}
]