[
{ "hval": -4262605793662658673,
  "pre": {"v3":"undefined"},
  "post": {}}
,
{ "hval": -7265530382583183660,
  "pre": {},
  "post": {"v0":"undefined"}}
,
{ "hval": -8638173231064382783,
  "pre": {},
  "post": {"v0":"function"}}
]