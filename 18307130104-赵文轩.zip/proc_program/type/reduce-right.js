[
{ "hval": -120385970724787964,
  "pre": {"v3":"undefined"},
  "post": {}}
,
{ "hval": -4144375167697826940,
  "pre": {"v1":"function"},
  "post": {"v1":"function"}}
,
{ "hval": -3987458632548678936,
  "pre": {"v1":"function"},
  "post": {}}
,
{ "hval": -669827548547540183,
  "pre": {},
  "post": {}}
,
{ "hval": 5560570679449019934,
  "pre": {"v2":"undefined","v3":"undefined","v4":"function"},
  "post": {}}
]