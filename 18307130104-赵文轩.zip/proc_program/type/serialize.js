[
{ "hval": -6254088878912117047,
  "pre": {},
  "post": {"v0":"number"}}
,
{ "hval": -964963668777278771,
  "pre": {},
  "post": {"v0":"undefined"}}
,
{ "hval": -8277037293077404557,
  "pre": {"v5":"number"},
  "post": {}}
,
{ "hval": 352673009270015067,
  "pre": {"v1":"function"},
  "post": {}}
,
{ "hval": 1661762617110070111,
  "pre": {},
  "post": {}}
,
{ "hval": 27917162051672773,
  "pre": {"v1":"function","v2":"Class"},
  "post": {}}
,
{ "hval": 4361998223048792433,
  "pre": {"v7":"function"},
  "post": {}}
,
{ "hval": -2726206592431052336,
  "pre": {},
  "post": {"v0":"number"}}
,
{ "hval": 6481459888475916189,
  "pre": {"v6":"undefined","v7":"number","v8":"number"},
  "post": {}}
,
{ "hval": 3315750177807910190,
  "pre": {"v1":"undefined","v2":"undefined"},
  "post": {}}
]