[
{ "hval": -7249826775171989363,
  "pre": {},
  "post": {"v0":"number"}}
,
{ "hval": 7245165126927635417,
  "pre": {"v2":"number"},
  "post": {"v0":"Array","v2":"number"}}
,
{ "hval": -758005282920777301,
  "pre": {"v0":"Array","v1":"number"},
  "post": {"v0":"Array","v1":"number"}}
,
{ "hval": 301682230413706004,
  "pre": {"v0":"Array","v1":"number"},
  "post": {"v0":"Array","v1":"number"}}
,
{ "hval": -5244119080633540939,
  "pre": {"v1":"Array"},
  "post": {"v1":"Array","v0":"undefined"}}
]