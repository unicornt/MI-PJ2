[
{ "hval": 4410767066787743636,
  "pre": {},
  "post": {}}
,
{ "hval": 6958424921375202045,
  "pre": {"v1":"string"},
  "post": {"v1":"string"}}
,
{ "hval": -3259562781673762473,
  "pre": {"v1":"function"},
  "post": {"v1":"function","v0":"string"}}
,
{ "hval": -964963668777278771,
  "pre": {},
  "post": {"v0":"undefined"}}
,
{ "hval": -224991651450959086,
  "pre": {},
  "post": {"v0":"function"}}
,
{ "hval": -7966098206520885350,
  "pre": {},
  "post": {"v0":"function"}}
,
{ "hval": -7322988536016407660,
  "pre": {},
  "post": {"v0":"function"}}
,
{ "hval": 7473368417884659290,
  "pre": {},
  "post": {"v0":"function"}}
,
{ "hval": 4331232549846536448,
  "pre": {"v3":"undefined","v2":"string"},
  "post": {}}
,
{ "hval": 2184606083763383504,
  "pre": {"v3":"undefined","v2":"string"},
  "post": {}}
,
{ "hval": 2075403858456358232,
  "pre": {"v3":"undefined","v5":"string"},
  "post": {}}
,
{ "hval": -4214427580285657111,
  "pre": {"v2":"undefined","v3":"string"},
  "post": {}}
]